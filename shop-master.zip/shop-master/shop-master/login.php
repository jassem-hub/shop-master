<?php
session_start();
require_once __DIR__ . '/controllers/AuthController.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = AuthController::login([
        'email' => $_POST['email'],
        'mot_de_passe' => $_POST['password']
    ]);
    if ($result['success']) {
        if ($result['user']->getRole() === 'admin') {
            header('Location: admin/dashboard.php');
        } else {
            header('Location: index.php');
        }
        exit;
    } else {
        $error = $result['message'];
    }
}

$title = 'Connexion';
require_once 'header.php';
?>

<header id="fh5co-header" class="fh5co-cover fh5co-cover-sm" role="banner" style="background-image:url(images/authentification.png);">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center">
                <div class="display-t">
                    <div class="display-tc animate-box" data-animate-effect="fadeIn">
                        <h1>Connexion</h1>
                        <h2>Connectez-vous à votre compte</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<div id="fh5co-contact">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 animate-box">
                <h3 class="text-center">Connexion</h3>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger" style="margin-bottom: 20px; padding: 15px; background: #f8d7da; border-radius: 8px; color: #721c24;">
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_GET['registered'])): ?>
                    <div class="alert alert-success" style="margin-bottom: 20px; padding: 15px; background: #d4edda; border-radius: 8px; color: #155724;">
                        Inscription réussie ! Vous pouvez maintenant vous connecter.
                    </div>
                <?php endif; ?>
                
                <form action="login.php" method="POST">
                    <div class="row form-group">
                        <div class="col-md-12">
                            <label for="email">Email</label>
                            <input type="email" name="email" id="email" class="form-control" placeholder="Votre email" required>
                        </div>
                    </div>
                    
                    <div class="row form-group">
                        <div class="col-md-12">
                            <label for="password">Mot de passe</label>
                            <input type="password" name="password" id="password" class="form-control" placeholder="Votre mot de passe" required>
                        </div>
                    </div>
                    
                    <div class="form-group text-center">
                        <input type="submit" value="Se connecter" class="btn btn-primary btn-lg" style="width: 100%;">
                    </div>
                </form>
                
                <div class="text-center" style="margin-top: 20px;">
                    <p>Pas encore de compte ? <a href="register.php">Inscrivez-vous</a></p>
                    <p style="font-size: 12px; color: #666;">Admin: admin@shop.com / admin123</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer_full.php'; ?>
