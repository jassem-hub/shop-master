<?php
session_start();
require_once __DIR__ . '/controllers/AuthController.php';
require_once __DIR__ . '/models/Utilisateur.php';

AuthController::requireLogin('login.php');

$user = Utilisateur::findById($_SESSION['user_id']);
if (!$user) {
    header('Location: logout.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        $user->setNom(htmlspecialchars(trim($_POST['nom'])));
        $user->setPrenom(htmlspecialchars(trim($_POST['prenom'])));
        $user->setAdresse(!empty($_POST['adresse']) ? htmlspecialchars(trim($_POST['adresse'])) : null);
        
        if ($user->update()) {
            $_SESSION['user_nom'] = $user->getNom();
            $_SESSION['user_prenom'] = $user->getPrenom();
            $success = 'Profil mis à jour avec succès';
        } else {
            $error = 'Erreur lors de la mise à jour';
        }
    }
    
    if (isset($_POST['change_password'])) {
        if ($_POST['new_password'] !== $_POST['confirm_password']) {
            $error = 'Les mots de passe ne correspondent pas';
        } elseif (strlen($_POST['new_password']) < 6) {
            $error = 'Le mot de passe doit contenir au moins 6 caractères';
        } else {
            if ($user->updatePassword($_POST['new_password'])) {
                $success = 'Mot de passe changé avec succès';
            } else {
                $error = 'Erreur lors du changement de mot de passe';
            }
        }
    }
}

$title = 'Mon Profil';
require_once 'header.php';
?>

<header id="fh5co-header" class="fh5co-cover fh5co-cover-sm" role="banner" style="background-image:url(images/profileImage.png);">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center">
                <div class="display-t">
                    <div class="display-tc animate-box" data-animate-effect="fadeIn">
                        <h1>Mon Profil</h1>
                        <h2>Gérez vos informations personnelles</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<div id="fh5co-contact">
    <div class="container">
        <?php if ($error): ?>
            <div class="alert alert-danger" style="margin-bottom: 20px; padding: 15px; background: #f8d7da; border-radius: 8px; color: #721c24;">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success" style="margin-bottom: 20px; padding: 15px; background: #d4edda; border-radius: 8px; color: #155724;">
                <?php echo htmlspecialchars($success); ?>
            </div>
        <?php endif; ?>
        
        <div class="row">
            <!-- Informations du profil -->
            <div class="col-md-6 animate-box">
                <h3>Informations personnelles</h3>
                <form action="profile.php" method="POST">
                    <input type="hidden" name="update_profile" value="1">
                    
                    <div class="row form-group">
                        <div class="col-md-6">
                            <label>Prénom</label>
                            <input type="text" name="prenom" class="form-control" value="<?php echo htmlspecialchars($user->getPrenom()); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label>Nom</label>
                            <input type="text" name="nom" class="form-control" value="<?php echo htmlspecialchars($user->getNom()); ?>" required>
                        </div>
                    </div>
                    
                    <div class="row form-group">
                        <div class="col-md-12">
                            <label>Email</label>
                            <input type="email" class="form-control" value="<?php echo htmlspecialchars($user->getEmail()); ?>" disabled>
                        </div>
                    </div>
                    
                    <div class="row form-group">
                        <div class="col-md-12">
                            <label>Adresse</label>
                            <textarea name="adresse" class="form-control" rows="3"><?php echo htmlspecialchars($user->getAdresse() ?? ''); ?></textarea>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <input type="submit" value="Mettre à jour" class="btn btn-primary">
                    </div>
                </form>
            </div>
            
          
            <div class="col-md-6 animate-box">
                <h3>Changer le mot de passe</h3>
                <form action="profile.php" method="POST">
                    <input type="hidden" name="change_password" value="1">
                    
                    <div class="row form-group">
                        <div class="col-md-12">
                            <label>Nouveau mot de passe</label>
                            <input type="password" name="new_password" class="form-control" placeholder="Min. 6 caractères" required minlength="6">
                        </div>
                    </div>
                    
                    <div class="row form-group">
                        <div class="col-md-12">
                            <label>Confirmer le mot de passe</label>
                            <input type="password" name="confirm_password" class="form-control" placeholder="Confirmez" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <input type="submit" value="Changer le mot de passe" class="btn btn-primary">
                    </div>
                </form>
                
                <hr style="margin: 40px 0;">
                
                <h3>Actions rapides</h3>
                <p>
                    <a href="orders.php" class="btn btn-outline">Mes commandes</a>
                    <a href="logout.php" class="btn btn-danger" style="margin-left: 10px;">Déconnexion</a>
                </p>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer_full.php'; ?>
