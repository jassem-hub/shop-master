<?php
$title = 'Services';
require_once 'header.php';
?>

<header id="fh5co-header" class="fh5co-cover fh5co-cover-sm" role="banner" style="background-image:url(images/service1.jpg);">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center">
                <div class="display-t">
                    <div class="display-tc animate-box" data-animate-effect="fadeIn">
                        <h1>Services</h1>
                        <h2>Découvrez ce que nous proposons</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<div id="fh5co-services" class="fh5co-bg-section">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-4 text-center">
                <div class="feature-center animate-box" data-animate-effect="fadeIn">
                    <span class="icon">
                        <i class="icon-circle-check"></i>
                    </span>
                    <h3>Paiement Sécurisé</h3>
                    <p>Paiement 100% sécurisé par carte bancaire ou PayPal. Vos données sont protégées.</p>
                    
                </div>
            </div>
            <div class="col-md-4 col-sm-4 text-center">
                <div class="feature-center animate-box" data-animate-effect="fadeIn">
                    <span class="icon">
                        <i class="icon-location"></i>
                    </span>
                    <h3>Livraison Rapide</h3>
                    <p>Livraison en 24-48h pour toute commande passée avant 14h. Suivi en temps réel.</p>
                   
                </div>
            </div>
            <div class="col-md-4 col-sm-4 text-center">
                <div class="feature-center animate-box" data-animate-effect="fadeIn">
                    <span class="icon">
                        <i class="icon-reply"></i>
                    </span>
                    <h3>Retour Gratuit</h3>
                    <p>30 jours pour retourner votre commande. Remboursement sous 7 jours.</p>
                   
                </div>
            </div>
        </div>
    </div>
</div>

<div id="fh5co-product">
    <div class="container">
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
                <span>Nos Atouts</span>
                <h2>Pourquoi nous choisir ?</h2>
                <p>Nous mettons tout en œuvre pour vous offrir la meilleure expérience d'achat</p>
            </div>
        </div>
        <div class="row animate-box">
            <div class="col-md-6">
                <h3>Notre Engagement</h3>
                <p>Chez Shop, nous nous engageons à vous offrir une expérience d'achat exceptionnelle. Nos produits sont soigneusement sélectionnés pour garantir qualité et satisfaction.</p>
                <ul>
                    <li><i class="icon-check"></i> Produits de qualité certifiés</li>
                    <li><i class="icon-check"></i> Service client disponible 7j/7</li>
                    <li><i class="icon-check"></i> Meilleurs prix garantis</li>
                    <li><i class="icon-check"></i> Livraison rapide et sécurisée</li>
                </ul>
            </div>
            <div class="col-md-6">
                <img class="img-responsive" src="images/Pourquoinouschoisir.png" alt="Nos services">
            </div>
        </div>
    </div>
</div>

<div id="fh5co-testimonial" class="fh5co-bg-section">
    <div class="container">
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
                <span>Témoignages</span>
                <h2>Ce que disent nos clients</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="row animate-box">
                    <div class="owl-carousel owl-carousel-fullwidth">
                        <div class="item">
                            <div class="testimony-slide active text-center">
                                <figure>
                                    <img src="images/person1.jpg" alt="user">
                                </figure>
                                <span>Sophie Martin, <a href="#" class="twitter">Cliente</a></span>
                                <blockquote>
                                    <p>&ldquo;Excellent service ! Livraison rapide et produits conformes à la description. Je recommande vivement !&rdquo;</p>
                                </blockquote>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimony-slide active text-center">
                                <figure>
                                    <img src="images/person2.jpg" alt="user">
                                </figure>
                                <span>Lucas Bernard, <a href="#" class="twitter">Client</a></span>
                                <blockquote>
                                    <p>&ldquo;Très satisfait de mon achat. Le service client est réactif et professionnel. Merci Shop !&rdquo;</p>
                                </blockquote>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimony-slide active text-center">
                                <figure>
                                    <img src="images/person3.jpg" alt="user">
                                </figure>
                                <span>Emma Petit, <a href="#" class="twitter">Cliente fidèle</a></span>
                                <blockquote>
                                    <p>&ldquo;Je commande régulièrement depuis 2 ans. Jamais déçue ! Qualité et prix au rendez-vous.&rdquo;</p>
                                </blockquote>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="fh5co-started">
    <div class="container">
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
                <h2>Newsletter</h2>
                <p>Abonnez-vous pour recevoir nos dernières offres et nouveautés</p>
            </div>
        </div>
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2">
                <form class="form-inline" action="contact.php" method="POST">
                    <div class="col-md-6 col-sm-6">
                        <div class="form-group">
                            <label for="email" class="sr-only">Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Votre email" required>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <button type="submit" class="btn btn-default btn-block">S'abonner</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer_full.php'; ?>
