<?php
session_start();
require_once __DIR__ . '/models/Produit.php';
require_once __DIR__ . '/controllers/OrderController.php';

$produitId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$produit = Produit::findById($produitId);

if (!$produit) {
    header('Location: products.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $result = OrderController::createOrder(
        $_SESSION['user_id'],
        $produitId,
        (int)$_POST['quantite']
    );
    if ($result['success']) {
        $success = 'Commande passée avec succès ! Vous pouvez la suivre dans votre espace client.';
    } else {
        $error = $result['message'];
    }
}

$title = htmlspecialchars($produit->getNom());
require_once 'header.php';
?>

<header id="fh5co-header" class="fh5co-cover fh5co-cover-sm" role="banner" style="background-image:url(images/img_bg_2.jpg);">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center">
                <div class="display-t">
                    <div class="display-tc animate-box" data-animate-effect="fadeIn">
                        <h1><?php echo htmlspecialchars($produit->getNom()); ?></h1>
                        <h2>Détails du produit</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<div id="fh5co-product">
    <div class="container">
        <div class="row">
            <div class="col-md-6 animate-box">
                <?php if ($produit->getImage()): ?>
                    <img src="public/uploads/<?php echo htmlspecialchars($produit->getImage()); ?>" class="img-responsive" style="border-radius: 10px; width: 100%;">
                <?php else: ?>
                    <img src="images/product-1.jpg" class="img-responsive" style="border-radius: 10px;">
                <?php endif; ?>
            </div>
            
            <div class="col-md-6 animate-box">
                <h1 style="font-size: 36px; margin-bottom: 20px;"><?php echo htmlspecialchars($produit->getNom()); ?></h1>
                
                <p class="price" style="font-size: 32px; color: #667eea; font-weight: bold; margin-bottom: 20px;">
                    <?php echo number_format($produit->getPrix(), 2); ?> €
                </p>
                
                <div class="desc" style="margin-bottom: 30px;">
                    <h3>Description</h3>
                    <p style="font-size: 16px; line-height: 1.8; color: #666;">
                        <?php echo nl2br(htmlspecialchars($produit->getDescription() ?? 'Aucune description disponible.')); ?>
                    </p>
                </div>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger" style="margin-bottom: 20px; padding: 15px; background: #f8d7da; border-radius: 8px; color: #721c24;">
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success" style="margin-bottom: 20px; padding: 15px; background: #d4edda; border-radius: 8px; color: #155724;">
                        <?php echo htmlspecialchars($success); ?>
                        <br><a href="orders.php" class="btn btn-primary btn-sm" style="margin-top: 10px;">Voir mes commandes</a>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['user_id'])): ?>
                    <form action="product_detail.php?id=<?php echo $produitId; ?>" method="POST">
                        <div class="row form-group">
                            <div class="col-md-4">
                                <label for="quantite">Quantité</label>
                                <input type="number" name="quantite" id="quantite" class="form-control" value="1" min="1" max="99" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary btn-lg" style="width: 100%;">
                                <i class="icon-shopping-cart"></i> Commander maintenant
                            </button>
                        </div>
                    </form>
                <?php else: ?>
                    <div class="alert alert-info" style="padding: 20px; background: #d1ecf1; border-radius: 8px; color: #0c5460;">
                        <p>Connectez-vous pour passer une commande.</p>
                        <a href="login.php" class="btn btn-primary" style="margin-top: 10px;">Se connecter</a>
                        <a href="register.php" class="btn btn-outline" style="margin-top: 10px; margin-left: 10px;">S'inscrire</a>
                    </div>
                <?php endif; ?>
                
                <div style="margin-top: 30px;">
                    <a href="products.php" class="btn btn-outline">← Retour aux produits</a>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="fh5co-started">
    <div class="container">
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
                <h2>Newsletter</h2>
                <p>Abonnez-vous pour recevoir nos dernières offres et nouveautés</p>
            </div>
        </div>
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2">
                <form class="form-inline" action="contact.php" method="POST">
                    <div class="col-md-6 col-sm-6">
                        <div class="form-group">
                            <label for="email" class="sr-only">Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Votre email" required>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <button type="submit" class="btn btn-default btn-block">S'abonner</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer_full.php'; ?>
