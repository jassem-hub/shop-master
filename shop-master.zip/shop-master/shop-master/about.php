<?php
$title = 'About Us';
require_once 'header.php';
?>

<header id="fh5co-header" class="fh5co-cover fh5co-cover-sm" role="banner" style="background-image:url(images/aboutus.jpg);">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center">
                <div class="display-t">
                    <div class="display-tc animate-box" data-animate-effect="fadeIn">
                        <h1>About Us</h1>
                        <h2>Découvrez notre histoire et notre équipe</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<div id="fh5co-about">
    <div class="container">
        <div class="about-content">
            <div class="row animate-box">
                <div class="col-md-6">
                    <div class="desc">
                        <h3>Notre Histoire</h3>
                        <p>Shop est né de la passion pour le commerce et le service client. Depuis notre création, nous nous efforçons de fournir les meilleurs produits à nos clients avec un service exceptionnel.</p>
                        <p>Notre équipe dévouée travaille sans relâche pour sélectionner des produits de qualité et garantir votre satisfaction à chaque achat.</p>
                    </div>
                    <div class="desc">
                        <h3>Notre Mission</h3>
                        <p>Notre mission est simple : offrir une expérience d'achat en ligne fluide, sécurisée et agréable. Nous croyons en la qualité, l'intégrité et le service client avant tout.</p>
                        <p>Nous sélectionnons rigoureusement nos fournisseurs pour vous proposer uniquement des produits qui répondent à nos critères stricts de qualité.</p>
                    </div>
                </div>
                <div class="col-md-6">
                    <img class="img-responsive" src="images/aboutus1.jpg" alt="about">
                </div>
            </div>
        </div>
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
                <span>Notre Équipe</span>
                <h2>Rencontrez notre équipe</h2>
                <p>Des professionnels dévoués à votre service</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 col-sm-4 animate-box" data-animate-effect="fadeIn">
                <div class="fh5co-staff">
                    <img src="images/person1.jpg" alt="Team Member">
                    <h3>Jean Dupont</h3>
                    <strong class="role">Directeur Général</strong>
                    <p>Avec plus de 15 ans d'expérience dans le commerce, Jean guide notre entreprise vers l'excellence.</p>
                    <ul class="fh5co-social-icons">
                        <li><a href="#"><i class="icon-facebook"></i></a></li>
                        <li><a href="#"><i class="icon-twitter"></i></a></li>
                        <li><a href="#"><i class="icon-linkedin"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-4 col-sm-4 animate-box" data-animate-effect="fadeIn">
                <div class="fh5co-staff">
                    <img src="images/person2.jpg" alt="Team Member">
                    <h3>Marie Martin</h3>
                    <strong class="role">Responsable Marketing</strong>
                    <p>Marie donne vie à notre marque et assure notre présence digitale avec créativité.</p>
                    <ul class="fh5co-social-icons">
                        <li><a href="#"><i class="icon-facebook"></i></a></li>
                        <li><a href="#"><i class="icon-twitter"></i></a></li>
                        <li><a href="#"><i class="icon-linkedin"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-4 col-sm-4 animate-box" data-animate-effect="fadeIn">
                <div class="fh5co-staff">
                    <img src="images/person3.jpg" alt="Team Member">
                    <h3>Pierre Leroy</h3>
                    <strong class="role">Responsable Logistique</strong>
                    <p>Pierre veille à ce que vos commandes soient préparées et livrées dans les meilleurs délais.</p>
                    <ul class="fh5co-social-icons">
                        <li><a href="#"><i class="icon-facebook"></i></a></li>
                        <li><a href="#"><i class="icon-twitter"></i></a></li>
                        <li><a href="#"><i class="icon-linkedin"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="fh5co-started">
    <div class="container">
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
                <h2>Newsletter</h2>
                <p>Abonnez-vous pour recevoir nos dernières offres et nouveautés</p>
            </div>
        </div>
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2">
                <form class="form-inline" action="contact.php" method="POST">
                    <div class="col-md-6 col-sm-6">
                        <div class="form-group">
                            <label for="email" class="sr-only">Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Votre email" required>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <button type="submit" class="btn btn-default btn-block">S'abonner</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer_full.php'; ?>
