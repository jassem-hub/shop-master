<?php
session_start();
require_once __DIR__ . '/controllers/AuthController.php';
require_once __DIR__ . '/controllers/OrderController.php';

AuthController::requireLogin('login.php');

$error = '';
$success = '';

if (isset($_GET['cancel']) && is_numeric($_GET['cancel'])) {
    $result = OrderController::cancelOrder((int)$_GET['cancel'], $_SESSION['user_id']);
    if ($result['success']) {
        $success = $result['message'];
    } else {
        $error = $result['message'];
    }
}

$commandes = OrderController::getUserOrders($_SESSION['user_id']);

$title = 'Mes Commandes';
require_once 'header.php';
?>

<header id="fh5co-header" class="fh5co-cover fh5co-cover-sm" role="banner" style="background-image:url(images/order.jpg);">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center">
                <div class="display-t">
                    <div class="display-tc animate-box" data-animate-effect="fadeIn">
                        <h1>Mes Commandes</h1>
                        <h2>Suivez vos commandes</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<div id="fh5co-product">
    <div class="container">
        <?php if ($error): ?>
            <div class="alert alert-danger" style="margin-bottom: 20px; padding: 15px; background: #f8d7da; border-radius: 8px; color: #721c24;">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success" style="margin-bottom: 20px; padding: 15px; background: #d4edda; border-radius: 8px; color: #155724;">
                <?php echo htmlspecialchars($success); ?>
            </div>
        <?php endif; ?>
        
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
                <span>Historique</span>
                <h2>Mes commandes (<?php echo count($commandes); ?>)</h2>
            </div>
        </div>
        
        <?php if (empty($commandes)): ?>
            <div class="row">
                <div class="col-md-8 col-md-offset-2 text-center">
                    <p style="font-size: 18px; color: #666; padding: 50px;">Vous n'avez pas encore passé de commande.</p>
                    <a href="products.php" class="btn btn-primary btn-lg">Découvrir nos produits</a>
                </div>
            </div>
        <?php else: ?>
            <div class="row">
                <div class="col-md-12">
                    <table class="table" style="background: #fff; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 15px rgba(0,0,0,0.08);">
                        <thead style="background: #f8f9fa;">
                            <tr>
                                <th style="padding: 20px;">N° Commande</th>
                                <th style="padding: 20px;">Produit</th>
                                <th style="padding: 20px;">Quantité</th>
                                <th style="padding: 20px;">Total</th>
                                <th style="padding: 20px;">Date</th>
                                <th style="padding: 20px;">Statut</th>
                                <th style="padding: 20px;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($commandes as $commande): ?>
                            <tr>
                                <td style="padding: 20px;">#<?php echo $commande['id']; ?></td>
                                <td style="padding: 20px;">
                                    <?php if ($commande['produit_image']): ?>
                                        <img src="public/uploads/<?php echo htmlspecialchars($commande['produit_image']); ?>" style="width: 50px; height: 50px; object-fit: cover; border-radius: 6px; margin-right: 10px; vertical-align: middle;">
                                    <?php endif; ?>
                                    <?php echo htmlspecialchars($commande['produit_nom']); ?>
                                </td>
                                <td style="padding: 20px;"><?php echo $commande['quantite']; ?></td>
                                <td style="padding: 20px;"><strong><?php echo number_format($commande['total'], 2); ?> €</strong></td>
                                <td style="padding: 20px;"><?php echo date('d/m/Y H:i', strtotime($commande['date_commande'])); ?></td>
                                <td style="padding: 20px;">
                                    <span style="padding: 6px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; background: <?php 
                                        echo match($commande['statut']) {
                                            'en_attente' => '#fff3cd',
                                            'confirmee' => '#d1ecf1',
                                            'expediee' => '#cce5ff',
                                            'livree' => '#d4edda',
                                            'annulee' => '#f8d7da',
                                            default => '#f0f0f0'
                                        };
                                    ?>; color: <?php 
                                        echo match($commande['statut']) {
                                            'en_attente' => '#856404',
                                            'confirmee' => '#0c5460',
                                            'expediee' => '#004085',
                                            'livree' => '#155724',
                                            'annulee' => '#721c24',
                                            default => '#666'
                                        };
                                    ?>;">
                                        <?php echo ucfirst(str_replace('_', ' ', $commande['statut'])); ?>
                                    </span>
                                </td>
                                <td style="padding: 20px;">
                                    <?php if ($commande['statut'] === 'en_attente'): ?>
                                        <a href="orders.php?cancel=<?php echo $commande['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Annuler cette commande?')">Annuler</a>
                                    <?php else: ?>
                                        <span style="color: #999;">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'footer_full.php'; ?>
