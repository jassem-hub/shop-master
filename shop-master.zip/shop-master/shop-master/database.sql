-- =============================================
-- E-COMMERCE DATABASE SCHEMA
-- Nom: shop_db
-- Description: Structure minimaliste pour un e-commerce PHP POO
-- =============================================

-- Création de la base de données
CREATE DATABASE IF NOT EXISTS shop_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE shop_db;

-- =============================================
-- TABLE UTILISATEURS
-- =============================================
CREATE TABLE utilisateurs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    mot_de_passe VARCHAR(255) NOT NULL,
    adresse TEXT,
    role ENUM('utilisateur', 'admin') DEFAULT 'utilisateur',
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    actif TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insertion d'un administrateur par défaut
-- Email: admin@shop.com | Mot de passe: admin123
INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, role) VALUES
('Admin', 'System', 'admin@shop.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- =============================================
-- TABLE PRODUITS
-- =============================================
CREATE TABLE produits (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(255) NOT NULL,
    description TEXT,
    prix DECIMAL(10, 2) NOT NULL,
    image VARCHAR(255),
    visible TINYINT(1) DEFAULT 1,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insertion de produits d'exemple
INSERT INTO produits (nom, description, prix, image, visible) VALUES
('T-shirt Premium', 'T-shirt 100% coton bio, coupe moderne et confortable. Disponible en plusieurs tailles.', 29.99, 'tshirt.jpg', 1),
('Casquette Sport', 'Casquette légère et respirante, idéale pour les activités sportives.', 19.99, 'casquette.jpg', 1),
('Sac à Dos Urban', 'Sac à dos multi-compartiments avec protection pour ordinateur portable.', 49.99, 'sac.jpg', 1),
('Bouteille Isotherme', 'Bouteille en inox isotherme, garde vos boissons froides 24h ou chaudes 12h.', 24.99, 'bouteille.jpg', 1),
('Chaussures Running', 'Chaussures de running légères avec amorti avancé.', 79.99, 'chaussures.jpg', 1);

-- =============================================
-- TABLE SLIDES (Slider Homepage)
-- =============================================
CREATE TABLE slides (
    id INT PRIMARY KEY AUTO_INCREMENT,
    image VARCHAR(255) NOT NULL,
    prix VARCHAR(20),
    titre VARCHAR(255) NOT NULL,
    description TEXT,
    bouton_text VARCHAR(100) DEFAULT 'Acheter',
    bouton_lien VARCHAR(255) DEFAULT 'products.php',
    ordre INT DEFAULT 0,
    actif TINYINT(1) DEFAULT 1,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO slides (image, prix, titre, description, bouton_text, bouton_lien, ordre) VALUES
('images/img_bg_1.jpg', '$100', 'The Alaskan', 'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.', 'Acheter', 'products.php', 1),
('images/img_bg_2.jpg', '$80', 'The Athenian', 'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.', 'Acheter', 'products.php', 2),
('images/img_bg_3.jpg', '$100', 'The Halife', 'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.', 'Acheter', 'products.php', 3),
('images/img_bg_4.jpg', '$100', 'The Presidential', 'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.', 'Acheter', 'products.php', 4);
