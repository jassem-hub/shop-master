<?php
require_once __DIR__ . '/../config/Database.php';

class Produit {
    private ?int $id;
    private string $nom;
    private ?string $description;
    private float $prix;
    private ?string $image;
    private bool $visible;
    private PDO $db;

    public function __construct(
        string $nom = '',
        ?string $description = null,
        float $prix = 0.0,
        ?string $image = null,
        bool $visible = true,
        ?int $id = null
    ) {
        $this->nom = $nom;
        $this->description = $description;
        $this->prix = $prix;
        $this->image = $image;
        $this->visible = $visible;
        $this->id = $id;
        $this->db = Database::getConnection();
    }

    public function getId(): ?int { return $this->id; }
    public function getNom(): string { return $this->nom; }
    public function getDescription(): ?string { return $this->description; }
    public function getPrix(): float { return $this->prix; }
    public function getImage(): ?string { return $this->image; }
    public function isVisible(): bool { return $this->visible; }

    public function setNom(string $nom): void { $this->nom = $nom; }
    public function setDescription(?string $description): void { $this->description = $description; }
    public function setPrix(float $prix): void { $this->prix = $prix; }
    public function setImage(?string $image): void { $this->image = $image; }
    public function setVisible(bool $visible): void { $this->visible = $visible; }

    public function create(): bool {
        $sql = "INSERT INTO produits (nom, description, prix, image, visible) 
                VALUES (:nom, :description, :prix, :image, :visible)";
        $stmt = $this->db->prepare($sql);
        $result = $stmt->execute([
            ':nom' => $this->nom,
            ':description' => $this->description,
            ':prix' => $this->prix,
            ':image' => $this->image,
            ':visible' => (int)$this->visible
        ]);
        if ($result) {
            $this->id = (int)$this->db->lastInsertId();
        }
        return $result;
    }

    public function update(): bool {
        if (!$this->id) return false;
        $sql = "UPDATE produits SET nom = :nom, description = :description, 
                prix = :prix, image = :image, visible = :visible WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':id' => $this->id,
            ':nom' => $this->nom,
            ':description' => $this->description,
            ':prix' => $this->prix,
            ':image' => $this->image,
            ':visible' => (int)$this->visible
        ]);
    }

    public function delete(): bool {
        if (!$this->id) return false;
        $sql = "DELETE FROM produits WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $this->id]);
    }

    public function softDelete(): bool {
        if (!$this->id) return false;
        $sql = "UPDATE produits SET visible = 0 WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $this->id]);
    }

    public static function findById(int $id): ?Produit {
        $db = Database::getConnection();
        $sql = "SELECT * FROM produits WHERE id = :id";
        $stmt = $db->prepare($sql);
        $stmt->execute([':id' => $id]);
        $data = $stmt->fetch();
        if (!$data) return null;
        return self::mapDataToProduit($data);
    }

    public static function findAllVisible(): array {
        $db = Database::getConnection();
        $sql = "SELECT * FROM produits WHERE visible = 1 ORDER BY date_creation DESC";
        $stmt = $db->query($sql);
        return $stmt->fetchAll();
    }

    public static function findAll(): array {
        $db = Database::getConnection();
        $sql = "SELECT * FROM produits ORDER BY date_creation DESC";
        $stmt = $db->query($sql);
        return $stmt->fetchAll();
    }

    public static function search(string $search): array {
        $db = Database::getConnection();
        $sql = "SELECT * FROM produits WHERE visible = 1 AND nom LIKE :search ORDER BY nom";
        $stmt = $db->prepare($sql);
        $stmt->execute([':search' => '%' . $search . '%']);
        return $stmt->fetchAll();
    }

    public static function sortByPrice(string $order = 'ASC'): array {
        $order = strtoupper($order) === 'DESC' ? 'DESC' : 'ASC';
        $db = Database::getConnection();
        $sql = "SELECT * FROM produits WHERE visible = 1 ORDER BY prix $order";
        $stmt = $db->query($sql);
        return $stmt->fetchAll();
    }

    private static function mapDataToProduit(array $data): Produit {
        return new Produit(
            $data['nom'],
            $data['description'],
            (float)$data['prix'],
            $data['image'],
            (bool)$data['visible'],
            (int)$data['id']
        );
    }
}
