<?php
require_once __DIR__ . '/../config/Database.php';

class Commande {
    private ?int $id;
    private int $utilisateurId;
    private int $produitId;
    private int $quantite;
    private float $total;
    private string $statut;
    private ?string $dateCommande;
    private PDO $db;

    public function __construct(
        int $utilisateurId = 0,
        int $produitId = 0,
        int $quantite = 1,
        float $total = 0.0,
        string $statut = 'en_attente',
        ?int $id = null,
        ?string $dateCommande = null
    ) {
        $this->utilisateurId = $utilisateurId;
        $this->produitId = $produitId;
        $this->quantite = $quantite;
        $this->total = $total;
        $this->statut = $statut;
        $this->id = $id;
        $this->dateCommande = $dateCommande;
        $this->db = Database::getConnection();
    }

    public function getId(): ?int { return $this->id; }
    public function getUtilisateurId(): int { return $this->utilisateurId; }
    public function getProduitId(): int { return $this->produitId; }
    public function getQuantite(): int { return $this->quantite; }
    public function getTotal(): float { return $this->total; }
    public function getStatut(): string { return $this->statut; }
    public function getDateCommande(): ?string { return $this->dateCommande; }

    public function setQuantite(int $quantite): void { $this->quantite = $quantite; }
    public function setTotal(float $total): void { $this->total = $total; }
    public function setStatut(string $statut): void { $this->statut = $statut; }

    public function create(): bool {
        $sql = "INSERT INTO commandes (utilisateur_id, produit_id, quantite, total, statut) 
                VALUES (:utilisateur_id, :produit_id, :quantite, :total, :statut)";
        $stmt = $this->db->prepare($sql);
        $result = $stmt->execute([
            ':utilisateur_id' => $this->utilisateurId,
            ':produit_id' => $this->produitId,
            ':quantite' => $this->quantite,
            ':total' => $this->total,
            ':statut' => $this->statut
        ]);
        if ($result) {
            $this->id = (int)$this->db->lastInsertId();
        }
        return $result;
    }

    public function updateStatut(string $nouveauStatut): bool {
        if (!$this->id) return false;
        $validStatuses = ['en_attente', 'confirmee', 'expediee', 'livree', 'annulee'];
        if (!in_array($nouveauStatut, $validStatuses)) return false;
        $sql = "UPDATE commandes SET statut = :statut WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':id' => $this->id,
            ':statut' => $nouveauStatut
        ]);
    }

    public function annuler(): bool {
        return $this->updateStatut('annulee');
    }

    public function delete(): bool {
        if (!$this->id) return false;
        $sql = "DELETE FROM commandes WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $this->id]);
    }

    public static function findById(int $id): ?array {
        $db = Database::getConnection();
        $sql = "SELECT c.*, p.nom as produit_nom, p.image as produit_image, 
                u.nom as user_nom, u.prenom as user_prenom 
                FROM commandes c 
                JOIN produits p ON c.produit_id = p.id 
                JOIN utilisateurs u ON c.utilisateur_id = u.id 
                WHERE c.id = :id";
        $stmt = $db->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetch() ?: null;
    }

    public static function findByUtilisateur(int $userId): array {
        $db = Database::getConnection();
        $sql = "SELECT c.*, p.nom as produit_nom, p.image as produit_image 
                FROM commandes c 
                JOIN produits p ON c.produit_id = p.id 
                WHERE c.utilisateur_id = :user_id 
                ORDER BY c.date_commande DESC";
        $stmt = $db->prepare($sql);
        $stmt->execute([':user_id' => $userId]);
        return $stmt->fetchAll();
    }

    public static function findAll(): array {
        $db = Database::getConnection();
        $sql = "SELECT c.*, p.nom as produit_nom, p.image as produit_image,
                u.nom as user_nom, u.prenom as user_prenom, u.email 
                FROM commandes c 
                JOIN produits p ON c.produit_id = p.id 
                JOIN utilisateurs u ON c.utilisateur_id = u.id 
                ORDER BY c.date_commande DESC";
        $stmt = $db->query($sql);
        return $stmt->fetchAll();
    }

    public static function findByStatut(string $statut): array {
        $db = Database::getConnection();
        $sql = "SELECT c.*, p.nom as produit_nom, p.image as produit_image,
                u.nom as user_nom, u.prenom as user_prenom, u.email 
                FROM commandes c 
                JOIN produits p ON c.produit_id = p.id 
                JOIN utilisateurs u ON c.utilisateur_id = u.id 
                WHERE c.statut = :statut 
                ORDER BY c.date_commande DESC";
        $stmt = $db->prepare($sql);
        $stmt->execute([':statut' => $statut]);
        return $stmt->fetchAll();
    }

    public static function countByUtilisateur(int $userId): int {
        $db = Database::getConnection();
        $sql = "SELECT COUNT(*) FROM commandes WHERE utilisateur_id = :user_id";
        $stmt = $db->prepare($sql);
        $stmt->execute([':user_id' => $userId]);
        return (int)$stmt->fetchColumn();
    }
}
