<?php
require_once __DIR__ . '/../config/Database.php';

class Utilisateur {
    private ?int $id;
    private string $nom;
    private string $prenom;
    private string $email;
    private string $motDePasse;
    private ?string $adresse;
    private string $role;
    private bool $actif;
    private PDO $db;

    public function __construct(
        string $nom = '',
        string $prenom = '',
        string $email = '',
        string $motDePasse = '',
        ?string $adresse = null,
        string $role = 'utilisateur',
        bool $actif = true,
        ?int $id = null
    ) {
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->email = $email;
        $this->motDePasse = $motDePasse;
        $this->adresse = $adresse;
        $this->role = $role;
        $this->actif = $actif;
        $this->id = $id;
        $this->db = Database::getConnection();
    }

    public function getId(): ?int { return $this->id; }
    public function getNom(): string { return $this->nom; }
    public function getPrenom(): string { return $this->prenom; }
    public function getEmail(): string { return $this->email; }
    public function getAdresse(): ?string { return $this->adresse; }
    public function getRole(): string { return $this->role; }
    public function isActif(): bool { return $this->actif; }

    public function setNom(string $nom): void { $this->nom = $nom; }
    public function setPrenom(string $prenom): void { $this->prenom = $prenom; }
    public function setEmail(string $email): void { $this->email = $email; }
    public function setAdresse(?string $adresse): void { $this->adresse = $adresse; }
    public function setMotDePasse(string $motDePasse): void { $this->motDePasse = $motDePasse; }

    public function create(): bool {
        $sql = "INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, adresse, role, actif) 
                VALUES (:nom, :prenom, :email, :mot_de_passe, :adresse, :role, :actif)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':nom' => $this->nom,
            ':prenom' => $this->prenom,
            ':email' => $this->email,
            ':mot_de_passe' => password_hash($this->motDePasse, PASSWORD_BCRYPT),
            ':adresse' => $this->adresse,
            ':role' => $this->role,
            ':actif' => (int)$this->actif
        ]);
    }

    public function update(): bool {
        if (!$this->id) return false;
        $sql = "UPDATE utilisateurs SET nom = :nom, prenom = :prenom, email = :email, 
                adresse = :adresse WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':id' => $this->id,
            ':nom' => $this->nom,
            ':prenom' => $this->prenom,
            ':email' => $this->email,
            ':adresse' => $this->adresse
        ]);
    }

    public function updatePassword(string $nouveauMotDePasse): bool {
        if (!$this->id) return false;
        $sql = "UPDATE utilisateurs SET mot_de_passe = :mot_de_passe WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':id' => $this->id,
            ':mot_de_passe' => password_hash($nouveauMotDePasse, PASSWORD_BCRYPT)
        ]);
    }

    public function delete(): bool {
        if (!$this->id) return false;
        $sql = "DELETE FROM utilisateurs WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $this->id]);
    }

    public function desactiver(): bool {
        if (!$this->id) return false;
        $sql = "UPDATE utilisateurs SET actif = 0 WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $this->id]);
    }

    public static function findById(int $id): ?Utilisateur {
        $db = Database::getConnection();
        $sql = "SELECT * FROM utilisateurs WHERE id = :id";
        $stmt = $db->prepare($sql);
        $stmt->execute([':id' => $id]);
        $data = $stmt->fetch();
        if (!$data) return null;
        return self::mapDataToUser($data);
    }

    public static function findByEmail(string $email): ?array {
        $db = Database::getConnection();
        $sql = "SELECT * FROM utilisateurs WHERE email = :email";
        $stmt = $db->prepare($sql);
        $stmt->execute([':email' => $email]);
        return $stmt->fetch() ?: null;
    }

    public static function findAll(): array {
        $db = Database::getConnection();
        $sql = "SELECT * FROM utilisateurs ORDER BY date_creation DESC";
        $stmt = $db->query($sql);
        return $stmt->fetchAll();
    }

    public static function authenticate(string $email, string $motDePasse): ?Utilisateur {
        $userData = self::findByEmail($email);
        if (!$userData) return null;
        if (!password_verify($motDePasse, $userData['mot_de_passe'])) return null;
        if (!$userData['actif']) return null;
        return self::mapDataToUser($userData);
    }

    private static function mapDataToUser(array $data): Utilisateur {
        return new Utilisateur(
            $data['nom'],
            $data['prenom'],
            $data['email'],
            '',
            $data['adresse'],
            $data['role'],
            (bool)$data['actif'],
            (int)$data['id']
        );
    }
}
