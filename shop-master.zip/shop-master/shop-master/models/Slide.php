<?php
require_once __DIR__ . '/../config/Database.php';

class Slide {
    private $id;
    private $image;
    private $prix;
    private $titre;
    private $description;
    private $bouton_text;
    private $bouton_lien;
    private $ordre;
    private $actif;
    private $date_creation;

    public function __construct($data = []) {
        $this->id = $data['id'] ?? null;
        $this->image = $data['image'] ?? '';
        $this->prix = $data['prix'] ?? '';
        $this->titre = $data['titre'] ?? '';
        $this->description = $data['description'] ?? '';
        $this->bouton_text = $data['bouton_text'] ?? 'Acheter';
        $this->bouton_lien = $data['bouton_lien'] ?? 'products.php';
        $this->ordre = $data['ordre'] ?? 0;
        $this->actif = $data['actif'] ?? 1;
        $this->date_creation = $data['date_creation'] ?? null;
    }

    public static function findAllActive() {
        $pdo = Database::getConnection();
        $stmt = $pdo->query('SELECT * FROM slides WHERE actif = 1 ORDER BY ordre ASC');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function findAll() {
        $pdo = Database::getConnection();
        $stmt = $pdo->query('SELECT * FROM slides ORDER BY ordre ASC');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function findById($id) {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM slides WHERE id = ?');
        $stmt->execute([$id]);
        $data = $stmt->fetch(PDO::FETCH_ASSOC);
        return $data ? new Slide($data) : null;
    }

    public function create() {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('INSERT INTO slides (image, prix, titre, description, bouton_text, bouton_lien, ordre, actif) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            $this->image,
            $this->prix,
            $this->titre,
            $this->description,
            $this->bouton_text,
            $this->bouton_lien,
            $this->ordre,
            $this->actif
        ]);
        $this->id = $pdo->lastInsertId();
        return $this->id;
    }

    public function update() {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE slides SET image = ?, prix = ?, titre = ?, description = ?, bouton_text = ?, bouton_lien = ?, ordre = ?, actif = ? WHERE id = ?');
        return $stmt->execute([
            $this->image,
            $this->prix,
            $this->titre,
            $this->description,
            $this->bouton_text,
            $this->bouton_lien,
            $this->ordre,
            $this->actif,
            $this->id
        ]);
    }

    public static function delete($id) {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('DELETE FROM slides WHERE id = ?');
        return $stmt->execute([$id]);
    }

    public function getId() { return $this->id; }
    public function getImage() { return $this->image; }
    public function getPrix() { return $this->prix; }
    public function getTitre() { return $this->titre; }
    public function getDescription() { return $this->description; }
    public function getBoutonText() { return $this->bouton_text; }
    public function getBoutonLien() { return $this->bouton_lien; }
    public function getOrdre() { return $this->ordre; }
    public function getActif() { return $this->actif; }

    public function setImage($image) { $this->image = $image; }
    public function setPrix($prix) { $this->prix = $prix; }
    public function setTitre($titre) { $this->titre = $titre; }
    public function setDescription($description) { $this->description = $description; }
    public function setBoutonText($bouton_text) { $this->bouton_text = $bouton_text; }
    public function setBoutonLien($bouton_lien) { $this->bouton_lien = $bouton_lien; }
    public function setOrdre($ordre) { $this->ordre = $ordre; }
    public function setActif($actif) { $this->actif = $actif; }
}
