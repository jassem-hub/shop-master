<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../models/Utilisateur.php';

class AuthController {
    public static function register(array $data): array {
        $required = ['nom', 'prenom', 'email', 'mot_de_passe', 'confirm_mot_de_passe'];
        foreach ($required as $field) {
            if (empty($data[$field])) {
                return ['success' => false, 'message' => 'Tous les champs obligatoires doivent être remplis'];
            }
        }
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            return ['success' => false, 'message' => 'Email invalide'];
        }
        if ($data['mot_de_passe'] !== $data['confirm_mot_de_passe']) {
            return ['success' => false, 'message' => 'Les mots de passe ne correspondent pas'];
        }
        if (strlen($data['mot_de_passe']) < 6) {
            return ['success' => false, 'message' => 'Le mot de passe doit contenir au moins 6 caractères'];
        }
        if (Utilisateur::findByEmail($data['email'])) {
            return ['success' => false, 'message' => 'Cet email est déjà utilisé'];
        }
        $user = new Utilisateur(
            htmlspecialchars(trim($data['nom'])),
            htmlspecialchars(trim($data['prenom'])),
            htmlspecialchars(trim($data['email'])),
            $data['mot_de_passe'],
            !empty($data['adresse']) ? htmlspecialchars(trim($data['adresse'])) : null,
            'utilisateur',
            true,
            null
        );
        if ($user->create()) {
            return ['success' => true, 'message' => 'Inscription réussie ! Connectez-vous.'];
        }
        return ['success' => false, 'message' => 'Erreur lors de l\'inscription'];
    }

    public static function login(array $data): array {
        if (empty($data['email']) || empty($data['mot_de_passe'])) {
            return ['success' => false, 'message' => 'Email et mot de passe requis'];
        }
        $user = Utilisateur::authenticate($data['email'], $data['mot_de_passe']);
        if (!$user) {
            return ['success' => false, 'message' => 'Email ou mot de passe incorrect'];
        }
        $_SESSION['user_id'] = $user->getId();
        $_SESSION['user_email'] = $user->getEmail();
        $_SESSION['user_role'] = $user->getRole();
        $_SESSION['user_nom'] = $user->getNom();
        $_SESSION['user_prenom'] = $user->getPrenom();
        return [
            'success' => true,
            'message' => 'Connexion réussie',
            'user' => $user,
            'is_admin' => $user->getRole() === 'admin'
        ];
    }

    public static function logout(): void {
        session_destroy();
        $_SESSION = [];
    }

    public static function isLoggedIn(): bool {
        return isset($_SESSION['user_id']);
    }

    public static function isAdmin(): bool {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
    }

    public static function getUserId(): ?int {
        return $_SESSION['user_id'] ?? null;
    }

    public static function requireLogin(string $redirect = 'login.php'): void {
        if (!self::isLoggedIn()) {
            header("Location: $redirect");
            exit;
        }
    }

    public static function requireAdmin(string $redirect = '../index.php'): void {
        if (!self::isLoggedIn() || !self::isAdmin()) {
            header("Location: $redirect");
            exit;
        }
    }

    public static function updateProfile(int $userId, array $data): array {
        $user = Utilisateur::findById($userId);
        if (!$user) {
            return ['success' => false, 'message' => 'Utilisateur non trouvé'];
        }
        if (!empty($data['nom'])) {
            $user->setNom(htmlspecialchars(trim($data['nom'])));
        }
        if (!empty($data['prenom'])) {
            $user->setPrenom(htmlspecialchars(trim($data['prenom'])));
        }
        if (!empty($data['email'])) {
            if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
                return ['success' => false, 'message' => 'Email invalide'];
            }
            $user->setEmail(htmlspecialchars(trim($data['email'])));
        }
        if (isset($data['adresse'])) {
            $user->setAdresse(htmlspecialchars(trim($data['adresse'])));
        }
        if ($user->update()) {
            $_SESSION['user_nom'] = $user->getNom();
            $_SESSION['user_prenom'] = $user->getPrenom();
            return ['success' => true, 'message' => 'Profil mis à jour avec succès'];
        }
        return ['success' => false, 'message' => 'Erreur lors de la mise à jour'];
    }

    public static function changePassword(int $userId, string $ancien, string $nouveau, string $confirmation): array {
        if (empty($ancien) || empty($nouveau) || empty($confirmation)) {
            return ['success' => false, 'message' => 'Tous les champs sont requis'];
        }
        if ($nouveau !== $confirmation) {
            return ['success' => false, 'message' => 'Les nouveaux mots de passe ne correspondent pas'];
        }
        if (strlen($nouveau) < 6) {
            return ['success' => false, 'message' => 'Le nouveau mot de passe doit contenir au moins 6 caractères'];
        }
        $userData = Utilisateur::findById($userId);
        if (!$userData) {
            return ['success' => false, 'message' => 'Utilisateur non trouvé'];
        }
        $fullData = Utilisateur::findByEmail($_SESSION['user_email']);
        if (!password_verify($ancien, $fullData['mot_de_passe'])) {
            return ['success' => false, 'message' => 'Ancien mot de passe incorrect'];
        }
        $user = Utilisateur::findById($userId);
        if ($user->updatePassword($nouveau)) {
            return ['success' => true, 'message' => 'Mot de passe changé avec succès'];
        }
        return ['success' => false, 'message' => 'Erreur lors du changement de mot de passe'];
    }
}
