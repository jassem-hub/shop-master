<?php
require_once __DIR__ . '/../models/Produit.php';

class AdminController {
    public static function createProduct(array $data, ?array $file = null): array {
        if (empty($data['nom']) || !isset($data['prix'])) {
            return ['success' => false, 'message' => 'Nom et prix sont obligatoires'];
        }

        $prix = (float)$data['prix'];
        if ($prix <= 0) {
            return ['success' => false, 'message' => 'Le prix doit être positif'];
        }
        $image = null;
        if ($file && $file['error'] === UPLOAD_ERR_OK) {
            $image = self::uploadImage($file);
            if (!$image) {
                return ['success' => false, 'message' => 'Erreur lors de l\'upload de l\'image'];
            }
        }
        $produit = new Produit(
            htmlspecialchars(trim($data['nom'])),
            !empty($data['description']) ? htmlspecialchars(trim($data['description'])) : null,
            $prix,
            $image,
            isset($data['visible']) ? (bool)$data['visible'] : true,
            null
        );

        if ($produit->create()) {
            return ['success' => true, 'message' => 'Produit créé avec succès'];
        }
        return ['success' => false, 'message' => 'Erreur lors de la création du produit'];
    }

    public static function updateProduct(int $id, array $data, ?array $file = null): array {
        $produit = Produit::findById($id);
        if (!$produit) {
            return ['success' => false, 'message' => 'Produit non trouvé'];
        }

        if (empty($data['nom']) || !isset($data['prix'])) {
            return ['success' => false, 'message' => 'Nom et prix sont obligatoires'];
        }

        $prix = (float)$data['prix'];
        if ($prix <= 0) {
            return ['success' => false, 'message' => 'Le prix doit être positif'];
        }

        if ($file && $file['error'] === UPLOAD_ERR_OK) {
            $image = self::uploadImage($file);
            if ($image) {
                if ($produit->getImage()) {
                    self::deleteImage($produit->getImage());
                }
                $produit->setImage($image);
            }
        }

        $produit->setNom(htmlspecialchars(trim($data['nom'])));
        $produit->setDescription(!empty($data['description']) ? htmlspecialchars(trim($data['description'])) : null);
        $produit->setPrix($prix);
        $produit->setVisible(isset($data['visible']) ? (bool)$data['visible'] : true);
        if ($produit->update()) {
            return ['success' => true, 'message' => 'Produit mis à jour avec succès'];
        }
        return ['success' => false, 'message' => 'Erreur lors de la mise à jour'];
    }

    public static function deleteProduct(int $id, bool $softDelete = true): array {
        $produit = Produit::findById($id);
        if (!$produit) {
            return ['success' => false, 'message' => 'Produit non trouvé'];
        }

        if ($softDelete) {
            if ($produit->softDelete()) {
                return ['success' => true, 'message' => 'Produit masqué avec succès'];
            }
        } else {
            if ($produit->getImage()) {
                self::deleteImage($produit->getImage());
            }
            if ($produit->delete()) {
                return ['success' => true, 'message' => 'Produit supprimé définitivement'];
            }
        }
        return ['success' => false, 'message' => 'Erreur lors de la suppression'];
    }

    public static function restoreProduct(int $id): array {
        $db = Database::getConnection();
        $sql = "UPDATE produits SET visible = 1 WHERE id = :id";
        $stmt = $db->prepare($sql);
        
        if ($stmt->execute([':id' => $id])) {
            return ['success' => true, 'message' => 'Produit restauré avec succès'];
        }
        return ['success' => false, 'message' => 'Erreur lors de la restauration'];
    }

    public static function deleteUser(int $id): array {
        if ($id == ($_SESSION['user_id'] ?? 0)) {
            return ['success' => false, 'message' => 'Vous ne pouvez pas supprimer votre propre compte'];
        }

        $user = Utilisateur::findById($id);
        if (!$user) {
            return ['success' => false, 'message' => 'Utilisateur non trouvé'];
        }

        if ($user->getRole() === 'admin') {
            return ['success' => false, 'message' => 'Impossible de supprimer un administrateur'];
        }

        if ($user->desactiver()) {
            return ['success' => true, 'message' => 'Utilisateur désactivé avec succès'];
        }
        return ['success' => false, 'message' => 'Erreur lors de la désactivation'];
    }

    public static function hardDeleteUser(int $id): array {
        if ($id == ($_SESSION['user_id'] ?? 0)) {
            return ['success' => false, 'message' => 'Vous ne pouvez pas supprimer votre propre compte'];
        }

        $user = Utilisateur::findById($id);
        if (!$user) {
            return ['success' => false, 'message' => 'Utilisateur non trouvé'];
        }

        if ($user->getRole() === 'admin') {
            return ['success' => false, 'message' => 'Impossible de supprimer un administrateur'];
        }

        if ($user->delete()) {
            return ['success' => true, 'message' => 'Utilisateur supprimé définitivement'];
        }
        return ['success' => false, 'message' => 'Erreur lors de la suppression'];
    }

    public static function updateOrderStatus(int $orderId, string $statut): array {
        $validStatuses = ['en_attente', 'confirmee', 'expediee', 'livree', 'annulee'];
        if (!in_array($statut, $validStatuses)) {
            return ['success' => false, 'message' => 'Statut invalide'];
        }

        $orderData = Commande::findById($orderId);
        if (!$orderData) {
            return ['success' => false, 'message' => 'Commande non trouvée'];
        }

        $order = new Commande(
            $orderData['utilisateur_id'],
            $orderData['produit_id'],
            $orderData['quantite'],
            $orderData['total'],
            $orderData['statut'],
            $orderData['id'],
            $orderData['date_commande']
        );

        if ($order->updateStatut($statut)) {
            return ['success' => true, 'message' => 'Statut mis à jour avec succès'];
        }
        return ['success' => false, 'message' => 'Erreur lors de la mise à jour du statut'];
    }

    private static function uploadImage(array $file): ?string {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $maxSize = 2 * 1024 * 1024;

        if (!in_array($file['type'], $allowedTypes)) {
            return null;
        }
        if ($file['size'] > $maxSize) {
            return null;
        }
        $uploadDir = __DIR__ . '/../public/uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid('prod_') . '.' . $extension;
        $destination = $uploadDir . $filename;

        if (move_uploaded_file($file['tmp_name'], $destination)) {
            return $filename;
        }
        return null;
    }

    private static function deleteImage(string $filename): void {
        $path = __DIR__ . '/../public/uploads/' . $filename;
        if (file_exists($path)) {
            unlink($path);
        }
    }
}
