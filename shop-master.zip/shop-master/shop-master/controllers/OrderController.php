<?php
require_once __DIR__ . '/../models/Commande.php';
require_once __DIR__ . '/../models/Produit.php';

class OrderController {
    public static function createOrder(int $userId, int $produitId, int $quantite): array {
        if ($quantite <= 0) {
            return ['success' => false, 'message' => 'La quantité doit être positive'];
        }
        $produit = Produit::findById($produitId);
        if (!$produit || !$produit->isVisible()) {
            return ['success' => false, 'message' => 'Produit non disponible'];
        }
        $total = $produit->getPrix() * $quantite;

        $commande = new Commande(
            $userId,
            $produitId,
            $quantite,
            $total,
            'en_attente',
            null,
            null
        );
        if ($commande->create()) {
            return [
                'success' => true,
                'message' => 'Commande créée avec succès',
                'order_id' => $commande->getId()
            ];
        }
        return ['success' => false, 'message' => 'Erreur lors de la création de la commande'];
    }

    public static function getUserOrders(int $userId): array {
        return Commande::findByUtilisateur($userId);
    }

    public static function getOrder(int $orderId, ?int $userId = null): ?array {
        $order = Commande::findById($orderId);
        if (!$order) {
            return null;
        }
        if ($userId !== null && $order['utilisateur_id'] != $userId) {
            return null;
        }
        return $order;
    }

    public static function cancelOrder(int $orderId, int $userId): array {
        $order = Commande::findById($orderId);
        if (!$order) {
            return ['success' => false, 'message' => 'Commande non trouvée'];
        }
        if ($order['utilisateur_id'] != $userId) {
            return ['success' => false, 'message' => 'Accès non autorisé'];
        }
        if ($order['statut'] !== 'en_attente') {
            return ['success' => false, 'message' => 'Cette commande ne peut plus être annulée'];
        }
        $commande = new Commande(
            $order['utilisateur_id'],
            $order['produit_id'],
            $order['quantite'],
            $order['total'],
            $order['statut'],
            $order['id'],
            $order['date_commande']
        );
        if ($commande->annuler()) {
            return ['success' => true, 'message' => 'Commande annulée avec succès'];
        }
        return ['success' => false, 'message' => 'Erreur lors de l\'annulation'];
    }

    public static function countUserOrders(int $userId): int {
        return Commande::countByUtilisateur($userId);
    }

    public static function getAllOrders(): array {
        return Commande::findAll();
    }

    public static function getOrdersByStatus(string $statut): array {
        return Commande::findByStatut($statut);
    }
}
