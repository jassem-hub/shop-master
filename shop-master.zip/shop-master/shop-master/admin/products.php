<?php
session_start();
require_once __DIR__ . '/../controllers/AuthController.php';
require_once __DIR__ . '/../controllers/AdminController.php';
require_once __DIR__ . '/../models/Produit.php';

AuthController::requireAdmin('../login.php');

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create') {
    $result = AdminController::createProduct($_POST, $_FILES['image'] ?? null);
    if ($result['success']) {
        $success = $result['message'];
    } else {
        $error = $result['message'];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $result = AdminController::updateProduct((int)$_POST['id'], $_POST, $_FILES['image'] ?? null);
    if ($result['success']) {
        $success = $result['message'];
    } else {
        $error = $result['message'];
    }
}

// Suppression
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $soft = !isset($_GET['hard']);
    $result = AdminController::deleteProduct((int)$_GET['delete'], $soft);
    if ($result['success']) {
        $success = $result['message'];
    } else {
        $error = $result['message'];
    }
}

// Restauration
if (isset($_GET['restore']) && is_numeric($_GET['restore'])) {
    $result = AdminController::restoreProduct((int)$_GET['restore']);
    if ($result['success']) {
        $success = $result['message'];
    } else {
        $error = $result['message'];
    }
}

$produits = Produit::findAll();
$produitEdit = null;
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $produitEdit = Produit::findById((int)$_GET['edit']);
}

$title = 'Gestion Produits - Admin';
$pageTitle = 'Gestion des Produits';
include 'header.php';
?>

<?php if ($error): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h3><?php echo $produitEdit ? 'Modifier le produit' : 'Ajouter un produit'; ?></h3>
    </div>
    <div class="card-body">
        <form action="products.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="<?php echo $produitEdit ? 'edit' : 'create'; ?>">
            <?php if ($produitEdit): ?>
                <input type="hidden" name="id" value="<?php echo $produitEdit->getId(); ?>">
            <?php endif; ?>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label class="form-label">Nom *</label>
                    <input type="text" name="nom" class="form-control" value="<?php echo $produitEdit ? htmlspecialchars($produitEdit->getNom()) : ''; ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Prix *</label>
                    <input type="number" name="prix" class="form-control" step="0.01" min="0" value="<?php echo $produitEdit ? htmlspecialchars($produitEdit->getPrix()) : ''; ?>" required>
                </div>
            </div>
            
            <div class="form-group">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control" rows="3"><?php echo $produitEdit ? htmlspecialchars($produitEdit->getDescription() ?? '') : ''; ?></textarea>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label class="form-label">Image</label>
                    <input type="file" name="image" class="form-control" accept="image/*">
                    <?php if ($produitEdit && $produitEdit->getImage()): ?>
                        <small style="color: #6c757d;">Image actuelle: <?php echo htmlspecialchars($produitEdit->getImage()); ?></small>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label class="form-label">Visible</label>
                    <select name="visible" class="form-control">
                        <option value="1" <?php echo ($produitEdit && $produitEdit->isVisible()) ? 'selected' : ''; ?>>Oui</option>
                        <option value="0" <?php echo ($produitEdit && !$produitEdit->isVisible()) ? 'selected' : ''; ?>>Non</option>
                    </select>
                </div>
            </div>
            
            <div class="form-group">
                <button type="submit" class="btn btn-primary"><?php echo $produitEdit ? 'Mettre à jour' : 'Ajouter'; ?></button>
                <?php if ($produitEdit): ?>
                    <a href="products.php" class="btn btn-secondary">Annuler</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h3>Liste des produits (<?php echo count($produits); ?>)</h3>
    </div>
    <div class="card-body" style="padding: 0;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Nom</th>
                    <th>Prix</th>
                    <th>Visible</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($produits as $produit): ?>
                <tr style="<?php echo !$produit['visible'] ? 'opacity: 0.6;' : ''; ?>">
                    <td>#<?php echo $produit['id']; ?></td>
                    <td>
                        <?php if ($produit['image']): ?>
                            <img src="../public/uploads/<?php echo htmlspecialchars($produit['image']); ?>" style="width: 50px; height: 50px; object-fit: cover; border-radius: 6px;">
                        <?php else: ?>
                            <span style="color: #adb5bd;">-</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo htmlspecialchars($produit['nom']); ?></td>
                    <td><strong><?php echo number_format($produit['prix'], 2); ?> €</strong></td>
                    <td>
                        <?php if ($produit['visible']): ?>
                            <span class="badge badge-success">Visible</span>
                        <?php else: ?>
                            <span class="badge badge-warning">Masqué</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="products.php?edit=<?php echo $produit['id']; ?>" class="btn btn-primary btn-sm">Modifier</a>
                        <?php if ($produit['visible']): ?>
                            <a href="products.php?delete=<?php echo $produit['id']; ?>" class="btn btn-warning btn-sm" onclick="return confirm('Masquer ce produit?')">Masquer</a>
                        <?php else: ?>
                            <a href="products.php?restore=<?php echo $produit['id']; ?>" class="btn btn-success btn-sm">Restaurer</a>
                        <?php endif; ?>
                        <a href="products.php?delete=<?php echo $produit['id']; ?>&hard=1" class="btn btn-danger btn-sm" onclick="return confirm('SUPPRIMER DÉFINITIVEMENT?')">Suppr</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'footer.php'; ?>
