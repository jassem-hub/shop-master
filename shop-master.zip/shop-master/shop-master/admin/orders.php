<?php
session_start();
require_once __DIR__ . '/../controllers/AuthController.php';
require_once __DIR__ . '/../controllers/AdminController.php';
require_once __DIR__ . '/../controllers/OrderController.php';

AuthController::requireAdmin('../login.php');

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $result = AdminController::updateOrderStatus((int)$_POST['order_id'], $_POST['statut']);
    if ($result['success']) {
        $success = $result['message'];
    } else {
        $error = $result['message'];
    }
}

$statutFilter = $_GET['statut'] ?? '';
if ($statutFilter) {
    $commandes = Commande::findByStatut($statutFilter);
} else {
    $commandes = OrderController::getAllOrders();
}

$title = 'Gestion Commandes - Admin';
$pageTitle = 'Gestion des Commandes';
include 'header.php';
?>

<?php if ($error): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
<?php endif; ?>

<div style="display: flex; gap: 10px; margin-bottom: 20px; flex-wrap: wrap;">
    <a href="orders.php" class="btn <?php echo empty($statutFilter) ? 'btn-primary' : 'btn-secondary'; ?>">Tous</a>
    <a href="orders.php?statut=en_attente" class="btn <?php echo $statutFilter === 'en_attente' ? 'btn-warning' : 'btn-secondary'; ?>">En attente</a>
    <a href="orders.php?statut=confirmee" class="btn <?php echo $statutFilter === 'confirmee' ? 'btn-primary' : 'btn-secondary'; ?>">Confirmées</a>
    <a href="orders.php?statut=expediee" class="btn <?php echo $statutFilter === 'expediee' ? 'btn-primary' : 'btn-secondary'; ?>">Expédiées</a>
    <a href="orders.php?statut=livree" class="btn <?php echo $statutFilter === 'livree' ? 'btn-success' : 'btn-secondary'; ?>">Livrées</a>
    <a href="orders.php?statut=annulee" class="btn <?php echo $statutFilter === 'annulee' ? 'btn-danger' : 'btn-secondary'; ?>">Annulées</a>
</div>

<div class="card">
    <div class="card-header">
        <h3>Liste des commandes (<?php echo count($commandes); ?>)</h3>
    </div>
    <div class="card-body" style="padding: 0;">
        <?php if (empty($commandes)): ?>
            <p style="padding: 40px; text-align: center; color: #6c757d;">Aucune commande.</p>
        <?php else: ?>
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>N°</th>
                        <th>Client</th>
                        <th>Produit</th>
                        <th>Qté</th>
                        <th>Total</th>
                        <th>Statut</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($commandes as $commande): ?>
                    <tr>
                        <td>#<?php echo $commande['id']; ?></td>
                        <td>
                            <strong><?php echo htmlspecialchars($commande['user_prenom'] . ' ' . $commande['user_nom']); ?></strong>
                            <br><small style="color: #6c757d;"><?php echo htmlspecialchars($commande['email']); ?></small>
                        </td>
                        <td>
                            <?php if ($commande['produit_image']): ?>
                                <img src="../public/uploads/<?php echo htmlspecialchars($commande['produit_image']); ?>" style="width: 40px; height: 40px; object-fit: cover; border-radius: 6px; margin-right: 8px; vertical-align: middle;">
                            <?php endif; ?>
                            <?php echo htmlspecialchars($commande['produit_nom']); ?>
                        </td>
                        <td><?php echo $commande['quantite']; ?></td>
                        <td><strong><?php echo number_format($commande['total'], 2); ?> €</strong></td>
                        <td>
                            <span class="badge badge-<?php 
                                echo match($commande['statut']) {
                                    'en_attente' => 'warning',
                                    'confirmee' => 'info',
                                    'expediee' => 'primary',
                                    'livree' => 'success',
                                    'annulee' => 'danger',
                                    default => 'secondary'
                                };
                            ?>">
                                <?php echo ucfirst(str_replace('_', ' ', $commande['statut'])); ?>
                            </span>
                        </td>
                        <td style="color: #6c757d; font-size: 13px;">
                            <?php echo date('d/m/Y H:i', strtotime($commande['date_commande'])); ?>
                        </td>
                        <td>
                            <form action="orders.php" method="POST" style="display: flex; gap: 5px;">
                                <input type="hidden" name="order_id" value="<?php echo $commande['id']; ?>">
                                <input type="hidden" name="update_status" value="1">
                                <select name="statut" class="form-control" style="width: 120px; padding: 6px; font-size: 12px;" onchange="this.form.submit()">
                                    <option value="en_attente" <?php echo $commande['statut'] === 'en_attente' ? 'selected' : ''; ?>>En attente</option>
                                    <option value="confirmee" <?php echo $commande['statut'] === 'confirmee' ? 'selected' : ''; ?>>Confirmée</option>
                                    <option value="expediee" <?php echo $commande['statut'] === 'expediee' ? 'selected' : ''; ?>>Expédiée</option>
                                    <option value="livree" <?php echo $commande['statut'] === 'livree' ? 'selected' : ''; ?>>Livrée</option>
                                    <option value="annulee" <?php echo $commande['statut'] === 'annulee' ? 'selected' : ''; ?>>Annulée</option>
                                </select>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?php include 'footer.php'; ?>
