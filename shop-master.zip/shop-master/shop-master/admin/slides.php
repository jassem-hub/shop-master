<?php
session_start();
require_once __DIR__ . '/../controllers/AuthController.php';
require_once __DIR__ . '/../models/Slide.php';

AuthController::requireAdmin('../login.php');

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create') {
    $slide = new Slide([
        'image' => $_POST['image'] ?? '',
        'prix' => $_POST['prix'] ?? '',
        'titre' => $_POST['titre'] ?? '',
        'description' => $_POST['description'] ?? '',
        'bouton_text' => $_POST['bouton_text'] ?? 'Acheter',
        'bouton_lien' => $_POST['bouton_lien'] ?? 'products.php',
        'ordre' => $_POST['ordre'] ?? 0,
        'actif' => isset($_POST['actif']) ? 1 : 0
    ]);
    $slide->create();
    $success = 'Slide créé avec succès';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $slide = Slide::findById((int)$_POST['id']);
    if ($slide) {
        $slide->setImage($_POST['image'] ?? '');
        $slide->setPrix($_POST['prix'] ?? '');
        $slide->setTitre($_POST['titre'] ?? '');
        $slide->setDescription($_POST['description'] ?? '');
        $slide->setBoutonText($_POST['bouton_text'] ?? 'Acheter');
        $slide->setBoutonLien($_POST['bouton_lien'] ?? 'products.php');
        $slide->setOrdre($_POST['ordre'] ?? 0);
        $slide->setActif(isset($_POST['actif']) ? 1 : 0);
        $slide->update();
        $success = 'Slide modifié avec succès';
    }
}

// Suppression
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    Slide::delete((int)$_GET['delete']);
    $success = 'Slide supprimé';
}

$slides = Slide::findAll();
$slideEdit = null;
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $slideEdit = Slide::findById((int)$_GET['edit']);
}

$title = 'Gestion Slides - Admin';
$pageTitle = 'Gestion des Slides';
include 'header.php';
?>

<?php if ($error): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h3><?php echo $slideEdit ? 'Modifier le slide' : 'Ajouter un slide'; ?></h3>
    </div>
    <div class="card-body">
        <form action="slides.php" method="POST">
            <input type="hidden" name="action" value="<?php echo $slideEdit ? 'edit' : 'create'; ?>">
            <?php if ($slideEdit): ?>
                <input type="hidden" name="id" value="<?php echo $slideEdit->getId(); ?>">
            <?php endif; ?>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label class="form-label">Image (chemin) *</label>
                    <input type="text" name="image" class="form-control" value="<?php echo $slideEdit ? htmlspecialchars($slideEdit->getImage()) : ''; ?>" required placeholder="images/slide.jpg">
                </div>
                <div class="form-group">
                    <label class="form-label">Prix</label>
                    <input type="text" name="prix" class="form-control" value="<?php echo $slideEdit ? htmlspecialchars($slideEdit->getPrix()) : ''; ?>" placeholder="$100">
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label class="form-label">Titre *</label>
                    <input type="text" name="titre" class="form-control" value="<?php echo $slideEdit ? htmlspecialchars($slideEdit->getTitre()) : ''; ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Ordre</label>
                    <input type="number" name="ordre" class="form-control" value="<?php echo $slideEdit ? htmlspecialchars($slideEdit->getOrdre()) : '0'; ?>">
                </div>
            </div>
            
            <div class="form-group">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control" rows="3"><?php echo $slideEdit ? htmlspecialchars($slideEdit->getDescription()) : ''; ?></textarea>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label class="form-label">Texte du bouton</label>
                    <input type="text" name="bouton_text" class="form-control" value="<?php echo $slideEdit ? htmlspecialchars($slideEdit->getBoutonText()) : 'Acheter'; ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Lien du bouton</label>
                    <input type="text" name="bouton_lien" class="form-control" value="<?php echo $slideEdit ? htmlspecialchars($slideEdit->getBoutonLien()) : 'products.php'; ?>">
                </div>
            </div>
            
            <div class="form-group">
                <label>
                    <input type="checkbox" name="actif" <?php echo ($slideEdit && $slideEdit->getActif()) || !$slideEdit ? 'checked' : ''; ?>> Actif
                </label>
            </div>
            
            <div class="form-group">
                <button type="submit" class="btn btn-primary"><?php echo $slideEdit ? 'Mettre à jour' : 'Ajouter'; ?></button>
                <?php if ($slideEdit): ?>
                    <a href="slides.php" class="btn btn-secondary">Annuler</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h3>Liste des slides (<?php echo count($slides); ?>)</h3>
    </div>
    <div class="card-body" style="padding: 0;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Ordre</th>
                    <th>Image</th>
                    <th>Titre</th>
                    <th>Prix</th>
                    <th>Actif</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($slides as $slide): ?>
                <tr style="<?php echo !$slide['actif'] ? 'opacity: 0.6;' : ''; ?>">
                    <td><?php echo $slide['ordre']; ?></td>
                    <td>
                        <img src="../<?php echo htmlspecialchars($slide['image']); ?>" style="width: 80px; height: 50px; object-fit: cover; border-radius: 6px;">
                    </td>
                    <td><?php echo htmlspecialchars($slide['titre']); ?></td>
                    <td><?php echo htmlspecialchars($slide['prix']); ?></td>
                    <td>
                        <?php if ($slide['actif']): ?>
                            <span class="badge badge-success">Actif</span>
                        <?php else: ?>
                            <span class="badge badge-warning">Inactif</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="slides.php?edit=<?php echo $slide['id']; ?>" class="btn btn-primary btn-sm">Modifier</a>
                        <a href="slides.php?delete=<?php echo $slide['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Supprimer ce slide?')">Supprimer</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'footer.php'; ?>
