<?php
session_start();
require_once __DIR__ . '/../controllers/AuthController.php';
require_once __DIR__ . '/../controllers/OrderController.php';
require_once __DIR__ . '/../models/Produit.php';
require_once __DIR__ . '/../models/Utilisateur.php';

AuthController::requireAdmin('../login.php');

$totalProduits = count(Produit::findAll());
$totalProduitsVisibles = count(Produit::findAllVisible());
$totalCommandes = count(Commande::findAll());
$totalUtilisateurs = count(Utilisateur::findAll());
$commandesRecentes = array_slice(Commande::findAll(), 0, 5);

$commandesParStatut = [
    'en_attente' => count(Commande::findByStatut('en_attente')),
    'confirmee' => count(Commande::findByStatut('confirmee')),
    'expediee' => count(Commande::findByStatut('expediee')),
    'livree' => count(Commande::findByStatut('livree')),
    'annulee' => count(Commande::findByStatut('annulee'))
];

$title = 'Admin Dashboard - Shop';
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $title; ?></title>
    
    <link rel="stylesheet" href="../css/animate.css">
    <link rel="stylesheet" href="../css/icomoon.css">
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Poppins', sans-serif;
            background: #f0f2f5;
        }
        
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 260px;
            height: 100vh;
            background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
            color: #fff;
            z-index: 1000;
        }
        
        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-header h2 {
            margin: 0;
            font-size: 26px;
            font-weight: 700;
        }
        
        .sidebar-header span {
            color: #d1c286;
        }
        
        .sidebar-menu {
            list-style: none;
            padding: 20px 0;
            margin: 0;
        }
        
        .sidebar-menu li {
            margin: 5px 15px;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            color: #a0a0a0;
            text-decoration: none;
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        
        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: rgba(209, 194, 134, 0.1);
            color: #d1c286;
        }
        
        .sidebar-menu i {
            margin-right: 15px;
            font-size: 18px;
        }
        
        .main-content {
            margin-left: 260px;
            padding: 30px;
            min-height: 100vh;
        }
        
        .top-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            padding: 20px 30px;
            background: #fff;
            border-radius: 15px;
            box-shadow: 0 2px 20px rgba(0,0,0,0.08);
        }
        
        .top-header h1 {
            margin: 0;
            font-size: 28px;
            color: #1a1a2e;
            font-weight: 600;
        }
        
        .user-actions {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .btn-site {
            background: #d1c286;
            color: #fff;
            padding: 10px 25px;
            border-radius: 8px;
            text-decoration: none;
        }
        
        .btn-logout {
            background: #f0f2f5;
            color: #1a1a2e;
            padding: 10px 25px;
            border-radius: 8px;
            text-decoration: none;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        
        .stat-card {
            background: #fff;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.08);
            display: flex;
            align-items: center;
            transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-icon {
            width: 70px;
            height: 70px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 30px;
            margin-right: 20px;
        }
        
        .stat-icon.blue { background: linear-gradient(135deg, #d1c286 0%, #b8a872 100%); color: #fff; }
        .stat-icon.pink { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: #fff; }
        .stat-icon.cyan { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: #fff; }
        .stat-icon.green { background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: #fff; }
        
        .stat-info h3 {
            margin: 0 0 5px 0;
            font-size: 32px;
            font-weight: 700;
            color: #1a1a2e;
        }
        
        .stat-info p {
            margin: 0;
            color: #888;
            font-size: 14px;
        }
        
        .content-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
        }
        
        @media (max-width: 1200px) {
            .content-grid {
                grid-template-columns: 1fr;
            }
        }
        
        .card {
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.08);
            padding: 30px;
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 20px;
            border-bottom: 2px solid #f0f2f5;
        }
        
        .card-header h3 {
            margin: 0;
            font-size: 20px;
            color: #1a1a2e;
            font-weight: 600;
        }
        
        .btn {
            padding: 8px 20px;
            border-radius: 8px;
            font-size: 13px;
            text-decoration: none;
            display: inline-block;
            border: none;
            cursor: pointer;
        }
        
        .btn-primary {
            background: #d1c286;
            color: #fff;
        }
        
        .admin-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .admin-table th {
            text-align: left;
            padding: 15px;
            color: #888;
            font-weight: 500;
            font-size: 13px;
            text-transform: uppercase;
        }
        
        .admin-table td {
            padding: 15px;
            border-top: 1px solid #f0f2f5;
        }
        
        .badge {
            padding: 8px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge-warning { background: #fff3cd; color: #856404; }
        .badge-info { background: #d1ecf1; color: #0c5460; }
        .badge-success { background: #d4edda; color: #155724; }
        .badge-danger { background: #f8d7da; color: #721c24; }
        .badge-primary { background: #cce5ff; color: #004085; }
        
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-top: 20px;
        }
        
        .quick-action {
            padding: 20px;
            background: #f8f9fa;
            border-radius: 15px;
            text-align: center;
            text-decoration: none;
            color: #1a1a2e;
            transition: all 0.3s ease;
        }
        
        .quick-action:hover {
            background: #d1c286;
            color: #fff;
        }
        
        .quick-action i {
            font-size: 24px;
            margin-bottom: 10px;
            display: block;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <h2 style="color: #fff;">Shop Admin</h2>
        </div>
        <ul class="sidebar-menu">
            <li>
                <a href="dashboard.php" class="active">
                    <i class="icon-dashboard"></i> Dashboard
                </a>
            </li>
            <li>
                <a href="products.php">
                    <i class="icon-shop"></i> Produits
                </a>
            </li>
            <li>
                <a href="orders.php">
                    <i class="icon-shopping-cart"></i> Commandes
                </a>
            </li>
            <li>
                <a href="users.php">
                    <i class="icon-users"></i> Utilisateurs
                </a>
            </li>
            <li>
                <a href="../index.php">
                    <i class="icon-globe"></i> Voir le site
                </a>
            </li>
            <li>
                <a href="../logout.php">
                    <i class="icon-sign-out"></i> Déconnexion
                </a>
            </li>
        </ul>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Top Header -->
        <div class="top-header">
            <h1>Tableau de bord</h1>
            <div class="user-actions">
                <span style="color: #666;">
                    <i class="icon-user"></i> 
                    <?php echo htmlspecialchars($_SESSION['user_prenom'] . ' ' . $_SESSION['user_nom']); ?>
                </span>
                <a href="../index.php" class="btn-site">Voir le site</a>
                <a href="../logout.php" class="btn-logout">Déconnexion</a>
            </div>
        </div>

        <!-- Stats Grid -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon blue">
                    <i class="icon-shop"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $totalProduits; ?></h3>
                    <p>Total Produits</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon pink">
                    <i class="icon-shopping-cart"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $totalCommandes; ?></h3>
                    <p>Total Commandes</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon cyan">
                    <i class="icon-users"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $totalUtilisateurs; ?></h3>
                    <p>Utilisateurs</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon green">
                    <i class="icon-eye"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $totalProduitsVisibles; ?></h3>
                    <p>Produits Visibles</p>
                </div>
            </div>
        </div>

        <!-- Content Grid -->
        <div class="content-grid">
            <!-- Recent Orders -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="icon-clock"></i> Commandes Récentes</h3>
                    <a href="orders.php" class="btn btn-primary">Voir tout</a>
                </div>
                
                <?php if (empty($commandesRecentes)): ?>
                    <p class="text-center text-muted">Aucune commande pour le moment.</p>
                <?php else: ?>
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Client</th>
                                <th>Produit</th>
                                <th>Total</th>
                                <th>Statut</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($commandesRecentes as $commande): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($commande['user_prenom'] . ' ' . $commande['user_nom']); ?></strong>
                                </td>
                                <td><?php echo htmlspecialchars($commande['produit_nom']); ?></td>
                                <td><strong><?php echo number_format($commande['total'], 2); ?> €</strong></td>
                                <td>
                                    <span class="badge badge-<?php 
                                        echo match($commande['statut']) {
                                            'en_attente' => 'warning',
                                            'confirmee' => 'primary',
                                            'expediee' => 'primary',
                                            'livree' => 'success',
                                            'annulee' => 'danger',
                                            default => 'secondary'
                                        };
                                    ?>">
                                        <?php echo ucfirst(str_replace('_', ' ', $commande['statut'])); ?>
                                    </span>
                                </td>
                                <td style="color: #888; font-size: 13px;">
                                    <?php echo date('d/m/Y H:i', strtotime($commande['date_commande'])); ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <!-- Quick Actions & Status -->
            <div>
                <!-- Order Status Summary -->
                <div class="card" style="margin-bottom: 30px;">
                    <div class="card-header">
                        <h3><i class="icon-pie-chart"></i> Résumé des Statuts</h3>
                    </div>
                    <div style="display: grid; gap: 15px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; padding: 15px; background: #fff3cd; border-radius: 10px;">
                            <span><i class="icon-clock"></i> En attente</span>
                            <strong style="color: #856404;"><?php echo $commandesParStatut['en_attente']; ?></strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; align-items: center; padding: 15px; background: #d1ecf1; border-radius: 10px;">
                            <span><i class="icon-check"></i> Confirmées</span>
                            <strong style="color: #0c5460;"><?php echo $commandesParStatut['confirmee']; ?></strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; align-items: center; padding: 15px; background: #cce5ff; border-radius: 10px;">
                            <span><i class="icon-truck"></i> Expédiées</span>
                            <strong style="color: #004085;"><?php echo $commandesParStatut['expediee']; ?></strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; align-items: center; padding: 15px; background: #d4edda; border-radius: 10px;">
                            <span><i class="icon-box"></i> Livrées</span>
                            <strong style="color: #155724;"><?php echo $commandesParStatut['livree']; ?></strong>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="icon-bolt"></i> Actions Rapides</h3>
                    </div>
                    <div class="quick-actions">
                        <a href="products.php?action=add" class="quick-action">
                            <i class="icon-plus"></i>
                            <span>Ajouter Produit</span>
                        </a>
                        <a href="orders.php" class="quick-action">
                            <i class="icon-list"></i>
                            <span>Voir Commandes</span>
                        </a>
                        <a href="users.php" class="quick-action">
                            <i class="icon-users"></i>
                            <span>Gérer Users</span>
                        </a>
                        <a href="../index.php" class="quick-action">
                            <i class="icon-globe"></i>
                            <span>Voir Site</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="../js/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
</body>
</html>
