<?php
if (!isset($title)) $title = 'Admin - Shop';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $title; ?></title>
    
    <link rel="stylesheet" href="../css/animate.css">
    <link rel="stylesheet" href="../css/icomoon.css">
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: #f5f7fa;
            color: #2c3e50;
        }
        
        .admin-sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 260px;
            height: 100vh;
            background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
            color: #fff;
            z-index: 1000;
            overflow-y: auto;
        }
        
        .admin-sidebar .logo {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.2);
        }
        
        .admin-sidebar .logo h2 {
            margin: 0;
            font-size: 24px;
            font-weight: 700;
        }
        
        .admin-sidebar .nav-menu {
            list-style: none;
            padding: 20px 0;
        }
        
        .admin-sidebar .nav-menu li {
            margin: 5px 15px;
        }
        
        .admin-sidebar .nav-menu a {
            display: block;
            padding: 12px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }
        
        .admin-sidebar .nav-menu a:hover,
        .admin-sidebar .nav-menu a.active {
            background: rgba(209, 194, 134, 0.1);
            color: #d1c286;
        }
        
        .admin-sidebar .nav-menu i {
            margin-right: 10px;
            width: 20px;
        }
        
        .admin-main {
            margin-left: 260px;
            min-height: 100vh;
        }
        
        .admin-header {
            background: #fff;
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .admin-header h1 {
            margin: 0;
            font-size: 24px;
            color: #2c3e50;
        }
        
        .admin-content {
            padding: 30px;
        }
        
        .card {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.08);
            margin-bottom: 25px;
        }
        
        .card-header {
            padding: 20px 25px;
            border-bottom: 1px solid #ecf0f1;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .card-header h3 {
            margin: 0;
            font-size: 18px;
            color: #2c3e50;
        }
        
        .card-body {
            padding: 25px;
        }
        
        .admin-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .admin-table th {
            text-align: left;
            padding: 15px;
            background: #f8f9fa;
            color: #6c757d;
            font-weight: 600;
            font-size: 13px;
            text-transform: uppercase;
        }
        
        .admin-table td {
            padding: 15px;
            border-top: 1px solid #ecf0f1;
        }
        
        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .badge-warning { background: #fff3cd; color: #856404; }
        .badge-info { background: #d1ecf1; color: #0c5460; }
        .badge-success { background: #d4edda; color: #155724; }
        .badge-danger { background: #f8d7da; color: #721c24; }
        
        .btn {
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: 500;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-primary {
            background: #d1c286;
            color: #fff;
        }
        
        .btn-success { background: #2ecc71; color: #fff; }
        .btn-danger { background: #e74c3c; color: #fff; }
        .btn-warning { background: #f39c12; color: #fff; }
        .btn-secondary { background: #95a5a6; color: #fff; }
        
        .btn-sm { padding: 6px 12px; font-size: 12px; }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #2c3e50;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .alert-success { background: #d4edda; color: #155724; }
        .alert-danger { background: #f8d7da; color: #721c24; }
    </style>
</head>
<body>
    <aside class="admin-sidebar">
        <div class="logo">
            <h2 style="color: #fff;">Shop Admin</h2>
        </div>
        <ul class="nav-menu">
            <li><a href="dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : ''; ?>"><i class="icon-dashboard"></i> Dashboard</a></li>
            <li><a href="products.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'products.php' ? 'active' : ''; ?>"><i class="icon-shop"></i> Produits</a></li>
            <li><a href="orders.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'orders.php' ? 'active' : ''; ?>"><i class="icon-shopping-cart"></i> Commandes</a></li>
            <li><a href="users.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'users.php' ? 'active' : ''; ?>"><i class="icon-users"></i> Utilisateurs</a></li>
            <li><a href="slides.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'slides.php' ? 'active' : ''; ?>"><i class="icon-image"></i> Slides</a></li>
            <li style="margin-top: 30px; border-top: 1px solid rgba(255,255,255,0.2); padding-top: 20px;">
                <a href="../index.php"><i class="icon-globe"></i> Voir le site</a>
            </li>
            <li><a href="../logout.php"><i class="icon-sign-out"></i> Déconnexion</a></li>
        </ul>
    </aside>

    <main class="admin-main">
        <header class="admin-header">
            <h1><?php echo $pageTitle ?? 'Administration'; ?></h1>
            <div style="display: flex; align-items: center; gap: 20px;">
                <span style="color: #6c757d;"><i class="icon-user"></i> <?php echo htmlspecialchars($_SESSION['user_prenom'] ?? ''); ?></span>
                <a href="../logout.php" class="btn btn-secondary btn-sm"><i class="icon-sign-out"></i> Déconnexion</a>
            </div>
        </header>
        <div class="admin-content">
