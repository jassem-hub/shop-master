<?php
session_start();
require_once __DIR__ . '/../controllers/AuthController.php';
require_once __DIR__ . '/../controllers/AdminController.php';
require_once __DIR__ . '/../models/Utilisateur.php';

AuthController::requireAdmin('../login.php');

$error = '';
$success = '';

if (isset($_GET['deactivate']) && is_numeric($_GET['deactivate'])) {
    $result = AdminController::deleteUser((int)$_GET['deactivate']);
    if ($result['success']) {
        $success = $result['message'];
    } else {
        $error = $result['message'];
    }
}

if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $result = AdminController::hardDeleteUser((int)$_GET['delete']);
    if ($result['success']) {
        $success = $result['message'];
    } else {
        $error = $result['message'];
    }
}

$utilisateurs = Utilisateur::findAll();

$title = 'Gestion Utilisateurs - Admin';
$pageTitle = 'Gestion des Utilisateurs';
include 'header.php';
?>

<?php if ($error): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
<?php endif; ?>

<!-- Stats -->
<div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 25px; margin-bottom: 25px;">
    <div class="card" style="padding: 20px; text-align: center;">
        <h3 style="font-size: 32px; color: #d1c286; margin: 0;"><?php echo count($utilisateurs); ?></h3>
        <p style="color: #6c757d; margin: 5px 0 0 0;">Total Utilisateurs</p>
    </div>
    <div class="card" style="padding: 20px; text-align: center;">
        <h3 style="font-size: 32px; color: #2ecc71; margin: 0;">
            <?php echo count(array_filter($utilisateurs, fn($u) => $u['actif'])); ?>
        </h3>
        <p style="color: #6c757d; margin: 5px 0 0 0;">Actifs</p>
    </div>
    <div class="card" style="padding: 20px; text-align: center;">
        <h3 style="font-size: 32px; color: #e74c3c; margin: 0;">
            <?php echo count(array_filter($utilisateurs, fn($u) => !$u['actif'])); ?>
        </h3>
        <p style="color: #6c757d; margin: 5px 0 0 0;">Inactifs</p>
    </div>
    <div class="card" style="padding: 20px; text-align: center;">
        <h3 style="font-size: 32px; color: #9b59b6; margin: 0;">
            <?php echo count(array_filter($utilisateurs, fn($u) => $u['role'] === 'admin')); ?>
        </h3>
        <p style="color: #6c757d; margin: 5px 0 0 0;">Admins</p>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h3>Liste des utilisateurs</h3>
    </div>
    <div class="card-body" style="padding: 0;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>Email</th>
                    <th>Rôle</th>
                    <th>Statut</th>
                    <th>Inscription</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($utilisateurs as $user): ?>
                <tr style="<?php echo !$user['actif'] ? 'opacity: 0.6;' : ''; ?>">
                    <td>#<?php echo $user['id']; ?></td>
                    <td>
                        <strong><?php echo htmlspecialchars($user['prenom'] . ' ' . $user['nom']); ?></strong>
                    </td>
                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                    <td>
                        <?php if ($user['role'] === 'admin'): ?>
                            <span class="badge badge-danger">Admin</span>
                        <?php else: ?>
                            <span class="badge badge-secondary">Client</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($user['actif']): ?>
                            <span class="badge badge-success">Actif</span>
                        <?php else: ?>
                            <span class="badge badge-warning">Inactif</span>
                        <?php endif; ?>
                    </td>
                    <td style="color: #6c757d;"><?php echo date('d/m/Y', strtotime($user['date_creation'])); ?></td>
                    <td>
                        <?php if ($user['id'] != $_SESSION['user_id'] && $user['role'] !== 'admin'): ?>
                            <?php if ($user['actif']): ?>
                                <a href="users.php?deactivate=<?php echo $user['id']; ?>" class="btn btn-warning btn-sm" onclick="return confirm('Désactiver cet utilisateur?')">Désactiver</a>
                            <?php endif; ?>
                            <a href="users.php?delete=<?php echo $user['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Supprimer définitivement cet utilisateur de la base de données?')">Supprimer</a>
                        <?php else: ?>
                            <span style="color: #adb5bd;">-</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'footer.php'; ?>
