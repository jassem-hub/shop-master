<?php
session_start();
$title = 'Contact';
$sent = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = 'Contact';
}
require_once 'header.php';
?>

<header id="fh5co-header" class="fh5co-cover fh5co-cover-sm" role="banner" style="background-image:url(images/ContactUs.jpg);">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center">
                <div class="display-t">
                    <div class="display-tc animate-box" data-animate-effect="fadeIn">
                        <h1>Contact Us</h1>
                        <h2>Nous sommes là pour vous aider</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<div id="fh5co-contact">
    <div class="container">
        <div class="row">
            <div class="col-md-5 col-md-push-1 animate-box">
                <div class="fh5co-contact-info">
                    <h3>Informations de contact</h3>
                    <ul>
                        <li class="address">sfax sakiet eddaier, <br> Tunisia</li>
                        <li class="phone"><a href="tel://1234567920">+ 216 54 048 499 <br> + 216 26 436 002</a></li>
                        <li class="email"><a href="mailto:info@shop.com">info@shop.com</a></li>
                        <li class="url"><a href="index.php">shop.com</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-6 animate-box">
                <h3>Envoyez-nous un message</h3>
                <?php if ($sent): ?>
                    <div class="alert alert-success" style="margin-bottom: 20px; padding: 15px; background: #d4edda; border-radius: 8px; color: #155724;">
                        Merci pour votre message ! Nous vous répondrons dans les plus brefs délais.
                    </div>
                <?php endif; ?>
                <form action="contact.php" method="POST">
                    <div class="row form-group">
                        <div class="col-md-6">
                            <input type="text" name="fname" class="form-control" placeholder="Votre prénom" required>
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="lname" class="form-control" placeholder="Votre nom" required>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col-md-12">
                            <input type="email" name="email" class="form-control" placeholder="Votre email" required>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col-md-12">
                            <input type="text" name="subject" class="form-control" placeholder="Sujet" required>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col-md-12">
                            <textarea name="message" cols="30" rows="10" class="form-control" placeholder="Votre message" required></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <input type="submit" value="Envoyer le message" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<div id="fh5co-started">
    <div class="container">
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
                <h2>Newsletter</h2>
                <p>Abonnez-vous pour recevoir nos dernières offres et nouveautés</p>
            </div>
        </div>
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2">
                <form class="form-inline" action="contact.php" method="POST">
                    <div class="col-md-6 col-sm-6">
                        <div class="form-group">
                            <label for="newsletter_email" class="sr-only">Email</label>
                            <input type="email" class="form-control" id="newsletter_email" name="email" placeholder="Votre email" required>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <button type="submit" class="btn btn-default btn-block">S'abonner</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer_full.php'; ?>
