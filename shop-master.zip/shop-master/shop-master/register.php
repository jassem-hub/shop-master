<?php
session_start();
require_once __DIR__ . '/controllers/AuthController.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = AuthController::register($_POST);
    if ($result['success']) {
        header('Location: login.php?registered=1');
        exit;
    } else {
        $error = $result['message'];
    }
}

$title = 'Inscription';
require_once 'header.php';
?>

<header id="fh5co-header" class="fh5co-cover fh5co-cover-sm" role="banner" style="background-image:url(images/img_bg_2.jpg);">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center">
                <div class="display-t">
                    <div class="display-tc animate-box" data-animate-effect="fadeIn">
                        <h1>Inscription</h1>
                        <h2>Créez votre compte client</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<div id="fh5co-contact">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 animate-box">
                <h3 class="text-center">Inscription</h3>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger" style="margin-bottom: 20px; padding: 15px; background: #f8d7da; border-radius: 8px; color: #721c24;">
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>
                
                <form action="register.php" method="POST">
                    <div class="row form-group">
                        <div class="col-md-6">
                            <label for="prenom">Prénom *</label>
                            <input type="text" name="prenom" id="prenom" class="form-control" placeholder="Votre prénom" required>
                        </div>
                        <div class="col-md-6">
                            <label for="nom">Nom *</label>
                            <input type="text" name="nom" id="nom" class="form-control" placeholder="Votre nom" required>
                        </div>
                    </div>
                    
                    <div class="row form-group">
                        <div class="col-md-12">
                            <label for="email">Email *</label>
                            <input type="email" name="email" id="email" class="form-control" placeholder="Votre email" required>
                        </div>
                    </div>
                    
                    <div class="row form-group">
                        <div class="col-md-12">
                            <label for="adresse">Adresse</label>
                            <textarea name="adresse" id="adresse" class="form-control" rows="2" placeholder="Votre adresse (optionnel)"></textarea>
                        </div>
                    </div>
                    
                    <div class="row form-group">
                        <div class="col-md-6">
                            <label for="mot_de_passe">Mot de passe *</label>
                            <input type="password" name="mot_de_passe" id="mot_de_passe" class="form-control" placeholder="Min. 6 caractères" required minlength="6">
                        </div>
                        <div class="col-md-6">
                            <label for="confirm_mot_de_passe">Confirmation *</label>
                            <input type="password" name="confirm_mot_de_passe" id="confirm_mot_de_passe" class="form-control" placeholder="Confirmez" required>
                        </div>
                    </div>
                    
                    <div class="form-group text-center">
                        <input type="submit" value="S'inscrire" class="btn btn-primary btn-lg" style="width: 100%;">
                    </div>
                </form>
                
                <div class="text-center" style="margin-top: 20px;">
                    <p>Déjà un compte ? <a href="login.php">Connectez-vous</a></p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer_full.php'; ?>
