<?php
session_start();
require_once __DIR__ . '/models/Produit.php';

$search = $_GET['search'] ?? '';
$sort = $_GET['sort'] ?? 'id_desc';

if ($search) {
    $produits = Produit::search($search);
} else {
    $produits = Produit::findAllVisible();
}

usort($produits, function($a, $b) use ($sort) {
    switch ($sort) {
        case 'prix_asc': return $a['prix'] <=> $b['prix'];
        case 'prix_desc': return $b['prix'] <=> $a['prix'];
        case 'nom_asc': return strcmp($a['nom'], $b['nom']);
        case 'id_desc':
        default: return $b['id'] <=> $a['id'];
    }
});

$title = 'Nos Produits';
require_once 'header.php';
?>

<header id="fh5co-header" class="fh5co-cover fh5co-cover-sm" role="banner" style="background-image:url(images/1.jpg);">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center">
                <div class="display-t">
                    <div class="display-tc animate-box" data-animate-effect="fadeIn">
                        <h1>Nos Produits</h1>
                        <h2>Découvrez notre collection</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<div id="fh5co-product">
    <div class="container">
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
                <span>Nouveautés</span>
                <h2>Nos Produits</h2>
                <p><?php echo count($produits); ?> produit(s) trouvé(s)</p>
            </div>
        </div>
        
        <!-- Filtres et recherche -->
        <div class="row" style="margin-bottom: 30px; display: flex; align-items: center;">
            <div class="col-md-6">
                <form action="products.php" method="GET" class="form-inline" style="display: flex; align-items: center; gap: 10px;">
                    <div class="input-group" style="width: 100%;">
                        <input type="text" name="search" class="form-control" placeholder="Rechercher un produit..." value="<?php echo htmlspecialchars($search); ?>">
                        <span class="input-group-btn">
                            <button type="submit" class="btn btn-primary" style="padding: 10px 15px;"><i class="icon-search"></i></button>
                        </span>
                    </div>
                </form>
            </div>
            <div class="col-md-6 text-right">
                <form action="products.php" method="GET" class="form-inline" style="display: flex; justify-content: flex-end; align-items: center; gap: 10px;">
                    <?php if ($search): ?>
                    <input type="hidden" name="search" value="<?php echo htmlspecialchars($search); ?>">
                    <?php endif; ?>
                    <label style="margin: 0;">Trier par:</label>
                    <select name="sort" class="form-control" style="width: auto;" onchange="this.form.submit()">
                        <option value="id_desc" <?php echo $sort === 'id_desc' ? 'selected' : ''; ?>>Nouveautés</option>
                        <option value="prix_asc" <?php echo $sort === 'prix_asc' ? 'selected' : ''; ?>>Prix: croissant</option>
                        <option value="prix_desc" <?php echo $sort === 'prix_desc' ? 'selected' : ''; ?>>Prix: décroissant</option>
                        <option value="nom_asc" <?php echo $sort === 'nom_asc' ? 'selected' : ''; ?>>Nom: A-Z</option>
                    </select>
                </form>
            </div>
        </div>
        
        <div class="row">
            <?php foreach ($produits as $produit): ?>
            <div class="col-md-4 text-center animate-box">
                <div class="product">
                    <div class="product-grid" style="background-image:url(<?php echo $produit['image'] ? 'public/uploads/' . htmlspecialchars($produit['image']) : 'images/product-1.jpg'; ?>);">
                        <span class="sale">Nouveau</span>
                        <div class="inner">
                            <p>
                                <a href="product_detail.php?id=<?php echo $produit['id']; ?>" class="icon"><i class="icon-eye"></i></a>
                            </p>
                        </div>
                    </div>
                    <div class="desc">
                        <h3><a href="product_detail.php?id=<?php echo $produit['id']; ?>"><?php echo htmlspecialchars($produit['nom']); ?></a></h3>
                        <span class="price"><?php echo number_format($produit['prix'], 2); ?> €</span>
                        <p style="color: #666; font-size: 13px; margin-top: 10px;">
                            <?php echo htmlspecialchars(substr($produit['description'] ?? '', 0, 80)) . (strlen($produit['description'] ?? '') > 80 ? '...' : ''); ?>
                        </p>
                        <a href="product_detail.php?id=<?php echo $produit['id']; ?>" class="btn btn-primary btn-sm" style="margin-top: 10px;">Voir détails</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            
            <?php if (empty($produits)): ?>
            <div class="col-md-12 text-center" style="padding: 50px;">
                <p style="font-size: 18px; color: #666;">Aucun produit trouvé.</p>
                <?php if ($search): ?>
                <a href="products.php" class="btn btn-primary">Voir tous les produits</a>
                <?php else: ?>
                <a href="admin/products.php" class="btn btn-primary">Ajouter des produits</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div id="fh5co-started">
    <div class="container">
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
                <h2>Newsletter</h2>
                <p>Abonnez-vous pour recevoir nos dernières offres et nouveautés</p>
            </div>
        </div>
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2">
                <form class="form-inline" action="contact.php" method="POST">
                    <div class="col-md-6 col-sm-6">
                        <div class="form-group">
                            <label for="email" class="sr-only">Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Votre email" required>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <button type="submit" class="btn btn-default btn-block">S'abonner</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer_full.php'; ?>
