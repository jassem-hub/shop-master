    <footer id="fh5co-footer" style="background: #1a1a2e; color: #fff; padding: 50px 0 20px;">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h3 style="color: #d1c286; margin-bottom: 20px;">Shop.</h3>
                    <p style="color: #a0a0a0;">Votre boutique en ligne de confiance. Qualité, service et prix au rendez-vous.</p>
                </div>
                <div class="col-md-4">
                    <h4 style="color: #d1c286; margin-bottom: 20px;">Liens Rapides</h4>
                    <ul style="list-style: none; padding: 0;">
                        <li style="margin-bottom: 10px;"><a href="about.php" style="color: #a0a0a0;">À propos</a></li>
                        <li style="margin-bottom: 10px;"><a href="products.php" style="color: #a0a0a0;">Boutique</a></li>
                        <li style="margin-bottom: 10px;"><a href="services.php" style="color: #a0a0a0;">Services</a></li>
                        <li style="margin-bottom: 10px;"><a href="contact.php" style="color: #a0a0a0;">Contact</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h4 style="color: #d1c286; margin-bottom: 20px;">Contact</h4>
                    <p style="color: #a0a0a0; margin-bottom: 10px;"><i class="icon-location"></i> sfax sakiet eddaier, Tunisia</p>
                    <p style="color: #a0a0a0; margin-bottom: 10px;"><i class="icon-globe"></i> info@shop.com</p>
                    <p style="color: #a0a0a0;"><i class="icon-phone"></i> +216 54 048 499</p>
                     <p style="color: #a0a0a0;"><i class="icon-phone"></i> +216 26 436 002</p>
                </div>
            </div>
            <div class="row" style="margin-top: 30px; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1);">
                <div class="col-md-12 text-center">
                    <p style="color: #a0a0a0; margin: 0;"><small>&copy; <?php echo date('Y'); ?> Shop. All Rights Reserved.</small></p>
                </div>
            </div>
        </div>
    </footer>
</div>

<div class="gototop js-top">
    <a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.countTo.js"></script>
<script src="js/jquery.flexslider-min.js"></script>
<script src="js/main.js"></script>

</body>
</html>
