<?php
session_start();
require_once __DIR__ . '/models/Produit.php';
require_once __DIR__ . '/models/Slide.php';

$produits = Produit::findAllVisible();
$produitsPopulaires = array_slice($produits, 0, 6);
$slides = Slide::findAllActive();

$title = 'Shop - Accueil';
require_once 'header.php';
?>

<aside id="fh5co-hero" class="js-fullheight">
    <div class="flexslider js-fullheight">
        <ul class="slides">
            <?php foreach ($slides as $slide): ?>
            <li style="background-image: url(<?php echo htmlspecialchars($slide['image']); ?>);">
                <div class="overlay-gradient"></div>
                <div class="container">
                    <div class="col-md-6 col-md-offset-3 col-md-pull-3 js-fullheight slider-text">
                        <div class="slider-text-inner">
                            <div class="desc">
                                <?php if ($slide['prix']): ?>
                                <span class="price"><?php echo htmlspecialchars($slide['prix']); ?></span>
                                <?php endif; ?>
                                <h2><?php echo htmlspecialchars($slide['titre']); ?></h2>
                                <p><?php echo htmlspecialchars($slide['description']); ?></p>
                                <p><a href="<?php echo htmlspecialchars($slide['bouton_lien']); ?>" class="btn btn-primary btn-outline btn-lg"><?php echo htmlspecialchars($slide['bouton_text']); ?></a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
            <?php endforeach; ?>
            <?php if (empty($slides)): ?>
            <li style="background-image: url(images/img_bg_1.jpg);">
                <div class="overlay-gradient"></div>
                <div class="container">
                    <div class="col-md-6 col-md-offset-3 col-md-pull-3 js-fullheight slider-text">
                        <div class="slider-text-inner">
                            <div class="desc">
                                <span class="price">Bienvenue</span>
                                <h2>Shop</h2>
                                <p>Découvrez nos produits de qualité</p>
                                <p><a href="products.php" class="btn btn-primary btn-outline btn-lg">Découvrir</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
            <?php endif; ?>
        </ul>
    </div>
</aside>

<div id="fh5co-services" class="fh5co-bg-section">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-4 text-center">
                <div class="feature-center animate-box" data-animate-effect="fadeIn">
                    <span class="icon">
                        <i class="icon-circle-check"></i>
                    </span>
                    <h3>Paiement Sécurisé</h3>
                    <p>Paiement 100% sécurisé par carte bancaire. Vos données sont protégées.</p>
                    <p><a href="products.php" class="btn btn-primary btn-outline">Découvrir</a></p>
                </div>
            </div>
            <div class="col-md-4 col-sm-4 text-center">
                <div class="feature-center animate-box" data-animate-effect="fadeIn">
                    <span class="icon">
                        <i class="icon-location"></i>
                    </span>
                    <h3>Livraison Rapide</h3>
                    <p>Livraison en 24-48h pour toute commande. Suivi en temps réel.</p>
                    <p><a href="products.php" class="btn btn-primary btn-outline">Commander</a></p>
                </div>
            </div>
            <div class="col-md-4 col-sm-4 text-center">
                <div class="feature-center animate-box" data-animate-effect="fadeIn">
                    <span class="icon">
                        <i class="icon-reply"></i>
                    </span>
                    <h3>Retour Gratuit</h3>
                    <p>30 jours pour retourner votre commande. Remboursement sous 7 jours.</p>
                    <p><a href="contact.php" class="btn btn-primary btn-outline">En savoir plus</a></p>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="fh5co-product">
    <div class="container">
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
                <span>Nouveautés</span>
                <h2>Nos Produits Populaires</h2>
                <p>Découvrez notre sélection de produits tendance</p>
            </div>
        </div>
        <div class="row">
            <?php foreach ($produitsPopulaires as $produit): ?>
            <div class="col-md-4 text-center animate-box">
                <div class="product">
                    <div class="product-grid" style="background-image:url(<?php echo $produit['image'] ? 'public/uploads/' . htmlspecialchars($produit['image']) : 'images/product-1.jpg'; ?>);">
                        <div class="inner">
                            <p>
                                <a href="product_detail.php?id=<?php echo $produit['id']; ?>" class="icon"><i class="icon-eye"></i></a>
                            </p>
                        </div>
                    </div>
                    <div class="desc">
                        <h3><a href="product_detail.php?id=<?php echo $produit['id']; ?>"><?php echo htmlspecialchars($produit['nom']); ?></a></h3>
                        <span class="price"><?php echo number_format($produit['prix'], 2); ?> €</span>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php if (empty($produitsPopulaires)): ?>
            <div class="col-md-12 text-center">
                <p>Aucun produit disponible pour le moment.</p>
                <a href="admin/products.php" class="btn btn-primary">Ajouter des produits</a>
            </div>
            <?php endif; ?>
        </div>
        <div class="row">
            <div class="col-md-12 text-center animate-box">
                <p><a href="products.php" class="btn btn-primary btn-outline btn-lg">Voir tous les produits</a></p>
            </div>
        </div>
    </div>
</div>

<div id="fh5co-testimonial" class="fh5co-bg-section">
    <div class="container">
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
                <span>Témoignages</span>
                <h2>Avis de nos clients</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="row animate-box">
                    <div class="owl-carousel owl-carousel-fullwidth">
                        <div class="item">
                            <div class="testimony-slide active text-center">
                                <figure>
                                    <img src="images/person1.jpg" alt="user">
                                </figure>
                                <span>Jean Dupont, via <a href="#" class="twitter">Twitter</a></span>
                                <blockquote>
                                    <p>&ldquo;Excellent site ! J'ai commandé plusieurs fois et je suis toujours satisfait de la qualité des produits et du service.&rdquo;</p>
                                </blockquote>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimony-slide active text-center">
                                <figure>
                                    <img src="images/person2.jpg" alt="user">
                                </figure>
                                <span>Marie Martin, via <a href="#" class="twitter">Twitter</a></span>
                                <blockquote>
                                    <p>&ldquo;Livraison rapide et produits conformes à la description. Je recommande vivement !&rdquo;</p>
                                </blockquote>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimony-slide active text-center">
                                <figure>
                                    <img src="images/person3.jpg" alt="user">
                                </figure>
                                <span>Pierre Leroy, via <a href="#" class="twitter">Twitter</a></span>
                                <blockquote>
                                    <p>&ldquo;Le service client est exceptionnel. Ils ont répondu rapidement à toutes mes questions.&rdquo;</p>
                                </blockquote>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="fh5co-counter" class="fh5co-bg-section" style="background-image: url(images/img_bg_5.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6 animate-box">
                <div class="feature-center">
                    <span class="icon">
                        <i class="icon-eye"></i>
                    </span>
                    <span class="counter js-counter" data-from="0" data-to="<?php echo count($produits); ?>" data-speed="5000" data-refresh-interval="50"><?php echo count($produits); ?></span>
                    <span class="counter-label">Produits</span>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 animate-box">
                <div class="feature-center">
                    <span class="icon">
                        <i class="icon-shopping-cart"></i>
                    </span>
                    <span class="counter js-counter" data-from="0" data-to="120" data-speed="5000" data-refresh-interval="50">120</span>
                    <span class="counter-label">Commandes</span>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 animate-box">
                <div class="feature-center">
                    <span class="icon">
                        <i class="icon-user"></i>
                    </span>
                    <span class="counter js-counter" data-from="0" data-to="80" data-speed="5000" data-refresh-interval="50">80</span>
                    <span class="counter-label">Clients satisfaits</span>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 animate-box">
                <div class="feature-center">
                    <span class="icon">
                        <i class="icon-heart"></i>
                    </span>
                    <span class="counter js-counter" data-from="0" data-to="100" data-speed="5000" data-refresh-interval="50">100%</span>
                    <span class="counter-label">Satisfaction</span>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="fh5co-started">
    <div class="container">
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
                <h2>Newsletter</h2>
                <p>Abonnez-vous pour recevoir nos dernières offres et nouveautés</p>
            </div>
        </div>
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2">
                <form class="form-inline" action="contact.php" method="POST">
                    <div class="col-md-6 col-sm-6">
                        <div class="form-group">
                            <label for="email" class="sr-only">Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Votre email" required>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <button type="submit" class="btn btn-default btn-block">S'abonner</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer_full.php'; ?>
